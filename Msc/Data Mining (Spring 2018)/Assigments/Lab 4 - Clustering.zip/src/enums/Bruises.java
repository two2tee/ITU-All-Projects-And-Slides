package enums;

public enum Bruises {
bruises,
no_bruises,
}
