package enums;

public enum Cap_Surface {
	fibrous,
	grooves,
	scaly,
	smooth,
}
