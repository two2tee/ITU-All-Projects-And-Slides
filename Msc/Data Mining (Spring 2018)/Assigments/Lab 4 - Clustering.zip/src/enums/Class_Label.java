package enums;

public enum Class_Label {
	edible,
	poisonous,
 }
