package enums;

public enum Veil_Type {
partial, 
universal,
}
