package enums;

public enum Ring_Number {
none,
one,
two, 
}
