package enums;

public enum Stalk_Shape {
	enlarging,
	tapering,
}
