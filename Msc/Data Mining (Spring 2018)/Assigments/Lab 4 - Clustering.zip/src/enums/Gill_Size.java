package enums;

public enum Gill_Size {
broad,
narrow,
}
