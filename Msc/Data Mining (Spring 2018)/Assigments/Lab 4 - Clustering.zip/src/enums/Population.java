package enums;

public enum Population {
	abundant,
	clustered,
	numerous,
	scattered,
	several,
	solitary,
}
