package enums;

public enum Veil_Color {
	brown,
	orange,
	white,
	yellow,
}
