package enums;

public enum Spore_Print_Color {
	black,
	brown,
	buff,
	chocolate,
	green,
	orange,
	purple,
	white,
	yellow,
}
