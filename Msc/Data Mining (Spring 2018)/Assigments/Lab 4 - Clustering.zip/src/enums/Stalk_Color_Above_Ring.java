package enums;

public enum Stalk_Color_Above_Ring {
	brown,
	buff,
	cinnamon,
	gray,
	orange,
	pink,
	red,
	white,
	yellow,
}
