package kMedoid;

import java.util.ArrayList;

import data.Iris;

public class KMedoid {

	public static ArrayList<KMedoidCluster> KMedoidPartition(int k, ArrayList<Iris> data)
	{
		return null;
		
	}
	
}
