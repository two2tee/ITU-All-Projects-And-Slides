package kMean;
import java.util.ArrayList;

import data.*;


public class KMeans {

	public static ArrayList<KMeanCluster> KMeansPartition(int k, ArrayList<Iris> data)
	{
		return null;
		
	}

}
