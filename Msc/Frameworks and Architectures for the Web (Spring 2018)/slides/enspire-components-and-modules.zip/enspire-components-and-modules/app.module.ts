import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { JsonpModule } from '@angular/http';

import { PhotoService } from './photo.service';

import { AppComponent } from './app.component';
import { PhotoMaster } from './photo-master.component'
import { PhotoDetail } from './photo-detail.component'

@NgModule({
  declarations: [
    AppComponent,
    PhotoMaster,
    PhotoDetail
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    JsonpModule
  ],
  providers: [
    PhotoService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
