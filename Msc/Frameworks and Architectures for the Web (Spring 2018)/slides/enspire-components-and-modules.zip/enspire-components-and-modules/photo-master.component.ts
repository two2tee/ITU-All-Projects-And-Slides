import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';

import { PhotoService } from './photo.service';

import { Photo } from './photo';

@Component({
  selector: 'photo-master',
  templateUrl: './photo-master.component.html',
  styleUrls: ['./photo-master.component.css']
})
export class PhotoMaster implements OnInit, OnChanges {

  currentPhoto: Photo;
  photos: Photo[];
  isSearching: boolean = false;

  @Input('search') searchString: string;
  @Output() select: EventEmitter<Photo> = new EventEmitter<Photo>();

  constructor(
    private photoService: PhotoService
  ) { }

  ngOnInit(): void {
    this.isSearching = true;
    this.searchString = 'copenhagen';
    this.search();
  }

  ngOnChanges(changes): void {
    this.searchString = changes.searchString.currentValue;
    this.search();
  }

  search(): void {
    this.isSearching = true;
    this.photos = [];
    this.photoService.getPhotos(this.searchString).then(photos =>{
      this.photos = photos;
      this.isSearching = false;
    });
  }

  selectPhoto(photo: Photo): void {
    this.currentPhoto = photo;
    this.select.emit(this.currentPhoto);
  }

}
