export class Photo {
  title: string;
  URL: string;
  imageURL: string;
  author: string;
  dateTaken: Date;
  tags: string[]
}
