import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { PhotoService } from './photo.service';
import { Photo } from './photo'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  searchText: string;
  photoSearchQuery: string;
  currentPhoto: Photo;

  photoSelect(photo: Photo) {
    this.currentPhoto = photo;
  }

  tagSelect(tag: string) {
    this.photoSearchQuery = tag;
  }

  search(e) {
    e.preventDefault();
    this.photoSearchQuery = this.searchText;
  }

}
