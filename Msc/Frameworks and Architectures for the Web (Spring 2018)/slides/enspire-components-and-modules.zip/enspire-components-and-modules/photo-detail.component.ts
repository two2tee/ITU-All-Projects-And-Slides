import { Component, Input, Output, EventEmitter } from '@angular/core';

import { Photo } from './photo';

@Component({
  selector: 'photo-detail',
  templateUrl: './photo-detail.component.html',
  styleUrls: ['./photo-detail.component.css']
})
export class PhotoDetail {

  @Input() photo: Photo;
  @Output() tagClick: EventEmitter<string> = new EventEmitter<string>();

  isEditingTitle: boolean = false;

  selectTag(e, tag: string) {
    e.preventDefault();
    this.tagClick.emit(tag);
  }

}
