import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'København';
  author = 'Tim Wray';
  dateTaken = new Date('1 April 2017');
  imageURL = 'http://farm5.staticflickr.com/4177/34380247115_efff2849ee_m.jpg';
  URL = 'http://www.flickr.com/photos/bertrandsketch/34380247115/';
  tags = ['one', 'two', 'three', 'four', 'harbour'];

  isEditing: boolean = false;
  newTagName: string;
  newTagErrorText: string;

  addTag() {
    if (this.newTagName) {
      if (this.tags.indexOf(this.newTagName) === -1) {
        this.tags.push(this.newTagName);
        this.newTagName = '';
        this.newTagErrorText = '';
      } else {
        this.newTagErrorText = 'Tag name already exists';
      }
    } else {
        this.newTagErrorText = 'Please enter a tag name.';
    }
  }

  removeTag(e, idx) {
    e.preventDefault();
    this.tags.splice(idx, 1);
  }

}
