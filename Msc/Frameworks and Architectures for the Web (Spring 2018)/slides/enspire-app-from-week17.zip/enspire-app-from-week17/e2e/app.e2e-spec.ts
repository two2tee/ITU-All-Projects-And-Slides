import { EnspireAppPage } from './app.po';

describe('enspire-app App', () => {
  let page: EnspireAppPage;

  beforeEach(() => {
    page = new EnspireAppPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
