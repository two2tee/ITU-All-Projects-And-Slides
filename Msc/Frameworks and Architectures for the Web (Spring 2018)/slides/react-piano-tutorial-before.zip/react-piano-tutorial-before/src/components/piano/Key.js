import React, { Component } from 'react';
import './Key.css';

export class Key extends Component {

  constructor() {
    super();
    this.note = {};
    this.noteSound = new Audio();
    this.handleKeyDown = this.handleKeyDown.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
  }

  componentDidMount() {
    this.note['pp'] = new Audio(`https://itu.dk/people/maco/piano-samples/pp/${this.props.pianoKey.note}.mp3`);
    this.note['mf'] = new Audio(`https://itu.dk/people/maco/piano-samples/mf/${this.props.pianoKey.note}.mp3`);
    this.note['ff'] = new Audio(`https://itu.dk/people/maco/piano-samples/ff/${this.props.pianoKey.note}.mp3`);
  }

  componentDidUpdate() {
    if (this.props.pianoKey.isPlayedAtDynamic !== 'none' && this.note[this.props.pianoKey.isPlayedAtDynamic].readyState === 4) {
      try {
        this.noteSound = this.note[this.props.pianoKey.isPlayedAtDynamic];
        this.noteSound.currentTime = 0.15;
        this.noteSound.play();
      } catch (e) {
        console.error('Unable to play note.');
      }
    } else if ((this.props.pianoKey.isPlayedAtDynamic === 'none')) {
      try {
        this.noteSound.pause();
      } catch (e) {
        console.error('Unable to stop note.');
      }
    }
  }

  handleKeyDown() {
    this.props.handleKeyDown(this.props.pianoKey);
  }

  handleKeyUp() {
    this.props.handleKeyUp(this.props.pianoKey);
  }

  render() {
    return (
      <div className={"key " + this.props.pianoKey.keyType + ' ' + (this.props.pianoKey.isPlayedAtDynamic !== 'none' ? 'pressed' : '')}
        onMouseDown={this.handleKeyDown}
        onMouseUp={this.handleKeyUp}>
      </div>
    )
  }

}
