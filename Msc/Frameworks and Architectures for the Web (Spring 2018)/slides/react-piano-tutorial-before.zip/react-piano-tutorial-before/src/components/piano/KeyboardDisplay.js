import React from 'react';
import './KeyboardDisplay.css';

export const KeyboardDisplay = (props) => {
  return (
    <span id="note-indicator">{props.displayedNote}</span>
  )
}
