import React, { Component } from 'react';
import './App.css';
import {KeyboardDisplay} from './components/piano/KeyboardDisplay.js';
import {Keyboard} from './components/piano/Keyboard.js';

class App extends Component {

  constructor() {
    super();
    this.state = {
      noteDisplay: '',
      keys: [
        {note: 'A0', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Bb0', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'B0', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'C1', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Db1', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'D1', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Eb1', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'E1', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'F1', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Gb1', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'G1', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Ab1', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'A1', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Bb1', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'B1', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'C2', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Db2', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'D2', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Eb2', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'E2', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'F2', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Gb2', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'G2', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Ab2', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'A2', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Bb2', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'B2', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'C3', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Db3', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'D3', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Eb3', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'E3', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'F3', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Gb3', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'G3', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Ab3', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'A3', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Bb3', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'B3', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'C4', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Db4', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'D4', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Eb4', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'E4', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'F4', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Gb4', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'G4', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Ab4', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'A4', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Bb4', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'B4', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'C5', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Db5', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'D5', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Eb5', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'E5', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'F5', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Gb5', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'G5', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Ab5', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'A5', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Bb5', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'B5', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'C6', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Db6', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'D6', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Eb6', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'E6', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'F6', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Gb6', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'G6', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Ab6', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'A6', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Bb6', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'B6', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'C7', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Db7', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'D7', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Eb7', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'E7', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'F7', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Gb7', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'G7', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Ab7', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'A7', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'Bb7', keyType: 'black', isPlayedAtDynamic: 'none'},
        {note: 'B7', keyType: 'white', isPlayedAtDynamic: 'none'},
        {note: 'C8', keyType: 'white', isPlayedAtDynamic: 'none'}
      ]
    }
    this.handleKeyDown = this.handleKeyDown.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
  }

  handleKeyDown (pianoKey) {
    console.log('key is pressed');
  }

  handleKeyUp (pianoKey) {
    console.log('key is raised');
  }

  render() {
    return (
      <div>
        <div>
          <KeyboardDisplay displayedNote={this.state.noteDisplay} />
          <Keyboard keys={this.state.keys} handleKeyDown={this.handleKeyDown} handleKeyUp={this.handleKeyUp} />
        </div>
      </div>
    );
  }

}

export default App;
