class Photo {
  title: string;
  URL: string;
  imageURL: string;
  author: string;
  dateTaken: Date;
  tags: string[]
}

const photos: Photo[] = [{
    "title": "Portrait (D80_474268)",
    "URL": "https://www.flickr.com/photos/itzick/33571103773/",
    "imageURL": "https://farm3.staticflickr.com/2839/33571103773_46a66bbcbf_m.jpg",
    "dateTaken": new Date("2017-04-25T13:57:26-08:00"),
    "author": "Itzick",
    "tags": ["denmark", "copenhagen", "candid", "woman", "hat", "maturewoman", "blackbackground", "bwportrait", "face", "d800", "itzick"]
}, {
    "title": "Portrait (D80_474163)",
    "URL": "https://www.flickr.com/photos/itzick/34250459111/",
    "imageURL": "https://farm3.staticflickr.com/2873/34250459111_8a9094a638_m.jpg",
    "dateTaken": new Date("2017-04-25T13:17:57-08:00"),
    "author": "Itzick",
    "tags": ["denmark", "copenhagen", "candid", "man", "beard", "whitebeard", "face", "streetphotography", "blackbackground", "d800", "itzick"]
}, {
    "title": "Portrait (D80_474202)",
    "URL": "https://www.flickr.com/photos/itzick/34250463221/",
    "imageURL": "https://farm3.staticflickr.com/2848/34250463221_4e46364a5e_m.jpg",
    "dateTaken": new Date("2017-04-25T13:38:33-08:00"),
    "author": "Itzick",
    "tags": ["denmark", "copenhagen", "candid", "man", "bwportrait", "beard", "blackbackground", "d800", "itzick", "streetphotography"]
}, {
    "title": "Copenhagen-Nyhavn-17.03-web",
    "URL": "https://www.flickr.com/photos/bertrandsketch/34380247115/",
    "imageURL": "https://farm5.staticflickr.com/4177/34380247115_efff2849ee_m.jpg",
    "dateTaken": new Date("2017-03-29T12:15:54-08:00"),
    "author": "bertrandfrancqueville",
    "tags": ["sketch", "copenhagen", "port", "nyhavn", "watercolor"]
}, {
    "title": "The Rush",
    "URL": "https://www.flickr.com/photos/93001635@N02/34249183271/",
    "imageURL": "https://farm3.staticflickr.com/2832/34249183271_1ba4807a5c_m.jpg",
    "dateTaken": new Date("2017-04-30T15:14:47-08:00"),
    "author": "Johnny H G",
    "tags": ["blackandwhite", "people", "architecture", "stairs", "copenhagen", "københavn", "denmark", "danmark", "canon", "eos"]
}, {
    "title": "DSC_4542-2",
    "URL": "https://www.flickr.com/photos/141843933@N07/34338210826/",
    "imageURL": "https://farm3.staticflickr.com/2830/34338210826_f90a140745_m.jpg",
    "dateTaken": new Date("2017-04-30T13:52:52-08:00"),
    "author": "simonbrandts\\u00f8rensen",
    "tags": ["portrait", "profile", "summer", "autumn", "girlfriend", "lakes", "copenhagen", "denmark", "sun"]
}, {
    "title": "Sakura Festival 2017",
    "URL": "https://www.flickr.com/photos/93001635@N02/34379244055/",
    "imageURL": "https://farm3.staticflickr.com/2846/34379244055_483899689b_m.jpg",
    "dateTaken": new Date("2017-04-30T12:53:46-08:00"),
    "author": "Johnny H G",
    "tags": ["sakurafestival", "copenhagen", "københavn", "2017", "japan", "outdoors", "naturallight", "canon", "eos"]
}, {
    "title": "Qatar 787 Pushback",
    "URL": "https://www.flickr.com/photos/81101914@N07/34378008655/",
    "imageURL": "https://farm3.staticflickr.com/2881/34378008655_19eb1da255_m.jpg",
    "dateTaken": new Date("2017-05-01T10:53:04-08:00"),
    "author": "Morten Hansen Aviation photography",
    "tags": ["qatar", "boeing", "787", "dreamliner", "pushback", "copenhagen", "sunset", "avgeek", "spotting", "planespotting", "aviation", "aircraft", "airplane", "air", "photography", "plane", "cph", "canon"]
}, {
    "title": "Blue Bullseye",
    "URL": "https://www.flickr.com/photos/149829109@N03/34336344976/",
    "imageURL": "https://farm3.staticflickr.com/2865/34336344976_8419ed1fd2_m.jpg",
    "dateTaken": new Date("2017-04-19T10:14:11-08:00"),
    "author": "Thomas Listl",
    "tags": ["thomaslistl", "color", "denmark", "copenhagen", "blue", "window", "graphic", "abstract", "light", "shadow", "architecture"]
}, {
    "title": "DSCF0032(1)",
    "URL": "https://www.flickr.com/photos/148549734@N03/34336324766/",
    "imageURL": "https://farm3.staticflickr.com/2823/34336324766_67c062b649_m.jpg",
    "dateTaken": new Date("2006-04-18T09:47:25-08:00"),
    "author": "harry_preston",
    "tags": ["copenhagen"]
}, {
    "title": "DSCF0031(2)",
    "URL": "https://www.flickr.com/photos/148549734@N03/34336325026/",
    "imageURL": "https://farm5.staticflickr.com/4177/34336325026_03b274983f_m.jpg",
    "dateTaken": new Date("2006-04-18T09:47:11-08:00"),
    "author": "harry_preston",
    "tags": ["copenhagen"]
}, {
    "title": "DSCF0018",
    "URL": "https://www.flickr.com/photos/148549734@N03/34377589505/",
    "imageURL": "https://farm5.staticflickr.com/4178/34377589505_592f0f6418_m.jpg",
    "dateTaken": new Date("2006-04-19T08:43:54-08:00"),
    "author": "harry_preston",
    "tags": ["copenhagen"]
}, {
    "title": "DSCF0012(1)",
    "URL": "https://www.flickr.com/photos/148549734@N03/33993006070/",
    "imageURL": "https://farm3.staticflickr.com/2860/33993006070_07a0c52034_m.jpg",
    "dateTaken": new Date("2006-04-18T13:19:26-08:00"),
    "author": "harry_preston",
    "tags": ["copenhagen"]
}, {
    "title": "DSCF0056",
    "URL": "https://www.flickr.com/photos/148549734@N03/33992980340/",
    "imageURL": "https://farm3.staticflickr.com/2859/33992980340_085b76a517_m.jpg",
    "dateTaken": new Date("2006-04-17T07:46:58-08:00"),
    "author": "harry_preston",
    "tags": ["copenhagen"]
}, {
    "title": "DSCF0005(1)",
    "URL": "https://www.flickr.com/photos/148549734@N03/33535637864/",
    "imageURL": "https://farm3.staticflickr.com/2815/33535637864_6fb14e278a_m.jpg",
    "dateTaken": new Date("2006-04-17T10:23:28-08:00"),
    "author": "harry_preston",
    "tags": ["copenhagen"]
}, {
    "title": "DSCF0053",
    "URL": "https://www.flickr.com/photos/148549734@N03/33992980540/",
    "imageURL": "https://farm3.staticflickr.com/2887/33992980540_6240e6f383_m.jpg",
    "dateTaken": new Date("2006-04-17T07:45:04-08:00"),
    "author": "harry_preston",
    "tags": ["copenhagen"]
}]
