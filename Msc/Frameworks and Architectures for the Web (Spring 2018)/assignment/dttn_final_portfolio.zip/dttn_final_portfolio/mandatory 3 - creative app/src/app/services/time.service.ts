// This service uses google timezone API to fetch the time offset between two locations
// It is responsible for returning the currect local time of a given location

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/internal/operators';

// https://developers.google.com/maps/documentation/timezone/intro
// https://www.techrepublic.com/article/convert-the-local-time-to-another-time-zone-with-this-javascript/

@Injectable()
export class TimeService {
  private baseUrl = 'https://maps.googleapis.com/maps/api';
  private key = 'AIzaSyBbBnSA4xH5DNW0V3RsG09Go4JLZhkpfsQ';

  constructor(
    private http: HttpClient,
  ) { }

  getTimeBasedOnLonLat(lat: number, lon: number, timestamp: number): Observable<Date> {
    const url = `${this.baseUrl}/timezone/json?location=${lat},${lon}&timestamp=${timestamp}&key=${this.key}`;

    return this.http.get<GoogleTimeResponse>(url).pipe(
      map((data: GoogleTimeResponse) => {
      const date = new Date(timestamp * 1000); // convert seconds to miliseconds
      const GMTtime = date.getTime(); // subtract timezone offset to get world time
      const timezoneHours = data.rawOffset * 1000; //  convert seconds to miliseconds
      const locationTime = GMTtime + timezoneHours;
      return new Date(locationTime);
    }));
  }

}

interface GoogleTimeResponse {
  dstOffset: number;
  rawOffset: number;
  status: string;
  timeZoneId: string;
  timeZoneName: string;
}
