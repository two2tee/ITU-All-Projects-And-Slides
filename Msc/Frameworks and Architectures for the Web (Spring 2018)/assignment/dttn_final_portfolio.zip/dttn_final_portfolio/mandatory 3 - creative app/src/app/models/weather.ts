// Primary model of web application
// This model contains all the data needed to
// represent a given weather state as well as the avatar informations

export class Weather {
  constructor(
      public avatarUrl,
      public avatarName,
      public isValid: boolean,
      public country: string,
      public city: string,
      public timestamp: Date,
      public cloudCoverage: number,
      public windSpeed: number,
      public windDeg: number,
      public isRaining: boolean,
      private temperature: number // kelvin
    ) {}

    public getTemperatureCelsius(): string {
      return (this.temperature - 273.15).toFixed(2); // subtract with celcius
    }

    public getTemperatureFahrenheit(): string {
      return (((this.temperature * 9) / 5) - 80.33).toFixed(2); // subtract with celcius
    }

}
