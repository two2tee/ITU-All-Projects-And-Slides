//This is the main module that handles the weather state
//The user input is parsed to weather service to retreive the data
//Initially a mock weather is used based on the users time.
//Geolocation is not used but has been considered

import {Component, OnInit} from '@angular/core';
import { Weather } from '../models/weather';
import { OpenMapWeatherService } from '../services/open-map-weather.service';
import { MockWeather } from '../models/mock-weather';
import {SearchModel} from '../models/searchModel';

@Component({
  selector: 'app-sky',
  templateUrl: './weather.component.html',
  styleUrls: ['./weather.component.css'],
})
export class WeatherComponent implements OnInit {
  pageTitle = 'Roboforecaster';
  currentWeather: Weather;
  skyState: string;
  cloudState: string;
  sunMoonState: string;

  hasSearched: boolean;
  temperatureTypes = ['celsius', 'fahrenheit'];

  searchModel: SearchModel;

  constructor(private weatherService: OpenMapWeatherService) {}

  ngOnInit() {
    this.searchModel = new SearchModel(this.temperatureTypes[0]);
    this.currentWeather = MockWeather;
    this.searchModel.selectedTemperature = this.temperatureTypes[0];
    this.updateSky();
    console.log('init weather');
  }

  onSearch() {
    if (this.searchModel.countryInput === null || this.searchModel.countryInput === '') {
      this.weatherService.getWeather(this.searchModel.cityInput).subscribe(fetchedWeather => {
        this.hasSearched = true;
        this.currentWeather = fetchedWeather;
        this.updateSky();
      });
    } else {
      this.weatherService.getWeatherCountry(this.searchModel.cityInput, this.searchModel.countryInput).subscribe(fetchedWeather => {
        this.hasSearched = true;
        this.currentWeather = fetchedWeather;
        this.updateSky();
      });
    }
  }


  isSkyClear() {
     return this.currentWeather.cloudCoverage < 50 && !this.currentWeather.isRaining;
  }


  isClouded(state: string): boolean {
    if (this.currentWeather.cloudCoverage > 0 && state === 'light' ) {
      return true;
    }
    else if (this.currentWeather.cloudCoverage >= 25 && state === 'medium' ) {
      return true;
    }
    else if (this.currentWeather.cloudCoverage >= 50 && state === 'dense') {
      return true;
    }
    return false;
  }

  private updateSky() {
    if (this.currentWeather.isValid) {
      this.setSkystate();
      this.setSunMoonState();
      this.setCloudRainstate();
    }
  }

  private setSunMoonState() {
    if (this.skyState === 'day' || this.skyState === 'evening') {
      this.sunMoonState = 'sun';
    }
    else {
      this.sunMoonState = 'moon';
    }
  }

  private setCloudRainstate() {
    if (this.currentWeather.isRaining) {
      this.cloudState = 'cloud-rain';
    }
    else {
      this.cloudState = 'cloud-normal';
    }
  }

  private setSkystate() {
    const hour = this.currentWeather.timestamp.getHours();
    if (hour >= 6 && hour < 18) {
      this.skyState = 'day';
    }
    else if (hour >= 18 && hour < 21) {
      this.skyState = 'evening';
    }
    else {
      this.skyState = 'night';
    }
  }


}
