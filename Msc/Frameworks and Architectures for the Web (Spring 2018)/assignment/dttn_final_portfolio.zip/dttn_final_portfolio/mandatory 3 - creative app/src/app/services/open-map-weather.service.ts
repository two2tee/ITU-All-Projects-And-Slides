// This service is responsible for fetching the current weather for a given city
// It uses openweathermap.org OPEN API

import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Weather } from '../models/weather';
import {catchError, map, mergeMap} from 'rxjs/internal/operators';
import {AvatarFetcherService} from './avatar-fetcher.service';
import { TimeService } from './time.service';

@Injectable()
export class OpenMapWeatherService {
  private baseUrl = 'https://api.openweathermap.org/data/2.5';
  private key = '5fd39c84fb914d69ef08711c999e5567';

  constructor(
    private avatarService: AvatarFetcherService,
    private timeService: TimeService,
    private http: HttpClient,

  ) { }


  getWeather(city: string): Observable<Weather> {
    const url = `${this.baseUrl}/weather?q=${city}&appid=${this.key}`;
    return this.fetchData(url, city);
  }

  getWeatherCountry(city: string, countryCode): Observable<Weather> {
    const url = `${this.baseUrl}/weather?q=${city},${countryCode}&appid=${this.key}`;
    return this.fetchData(url, city);
  }

  private fetchData(url: string, tag: string): Observable<Weather> {
    return this.http.get(url).pipe(
      mergeMap((weatherData: Data) => {
        return this.getDate(weatherData).pipe(map((date: Date) => this.convertToModel(weatherData, date ))); }),
      catchError((err: HttpErrorResponse) => {
        console.log(err.message);
        return this.getErrorModel(tag);
    })); // Fetch time of location after weather data has been fetched));


  }

  private getErrorModel(tag: string): Observable<Weather> {
    const model = new Weather(
      this.avatarService.getNotFoundAvatarUrl(tag),
      tag, false, '', '', new Date(Date.now()), 49, 0, 0, false, 0,
    );
    return new Observable(subscriber => subscriber.next(model));
  }

  // Converts retrieved data to domain model
  private convertToModel(jsonData: Data, date: Date): Weather {
    return new Weather(
      this.avatarService.getAvatarImageUrl(jsonData.name),
      this.avatarService.getAvatarName(jsonData.name),
      true,                              // valid weather data
      jsonData.sys.country,                     // country name
      jsonData.name,                            // City Name
      date,                 // Timestamp
      jsonData.clouds.all,                      // Cloud coverage
      jsonData.wind.speed,                      // Wind speed
      jsonData.wind.deg,                          // wind degree
      this.isRaining(jsonData),                 // If raining
      jsonData.main.temp                        // Tempurature
    );
  }

  // Retrieves data of location
  private getDate(jsonData: Data): Observable<Date> {
    return this.timeService.getTimeBasedOnLonLat(jsonData.coord.lat, jsonData.coord.lon, jsonData.dt);
  }

  private isRaining(jsonData: Data): boolean {
    if (jsonData .weather.length === 0 || jsonData .weather[0].main == null) { return false; }
    return jsonData .weather[0].main.toLowerCase() === 'rain';
  }

}

// Define model of open weather map to enable strongly typed instances
interface Data {
  coord: Coords;
  main: Main;
  sys: Sys;
  dt: number;
  name: string;
  weather: WeatherData[];
  clouds: Clouds;
  wind: Wind;
}

interface WeatherData {
  main: string;
  description: string;
  icon: string;
}

interface Main {
  temp: number;
  pressure: number;
  humidity: number;
}

interface Wind {
  speed: number;
  deg: number;
}

interface Clouds {
  all: number;
}

interface Sys {
  country: string;
}

interface Coords {
  lon: number;
  lat: number;
}



