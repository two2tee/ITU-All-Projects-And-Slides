export class SearchModel {
  cityInput: string;
  countryInput: string;
  selectedTemperature: string;

  constructor(defaultTemp: string) {
    this.selectedTemperature = defaultTemp;
  }
}
