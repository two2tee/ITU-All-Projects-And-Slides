import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { WeatherComponent } from './weather/weather.component';
import { OpenMapWeatherService } from './services/open-map-weather.service';
import { TimeService } from './services/time.service';
import { AvatarFetcherService } from './services/avatar-fetcher.service';
import { WeatherDetailsComponent } from './weather-details/weather-details.component';


@NgModule({
  declarations: [
    AppComponent,
    WeatherComponent,
    WeatherDetailsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    OpenMapWeatherService,
    TimeService,
    AvatarFetcherService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
