// the initial weather used when entering the page.
// The page is just syncing with the time while all other values
// are default. Eg clouds and sun/moon is visible.
// Geolocation would also have been an option to include.
// Thus the mock would only be used if the location could not be
// retrieved

import { Weather } from './weather';

export const MockWeather: Weather = new Weather(
    null,
    '',
    true,
    '', // Country
    '', // city
     new Date(Date.now()), // timestamp
    25, // cloud coverage
    0, // wind speed
    0, // wind degree
    false, // is raining
    0); // temperature
