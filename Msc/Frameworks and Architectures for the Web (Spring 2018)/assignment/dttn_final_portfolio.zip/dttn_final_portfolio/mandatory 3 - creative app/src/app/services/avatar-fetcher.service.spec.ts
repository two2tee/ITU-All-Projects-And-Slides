import { TestBed, inject } from '@angular/core/testing';

import { AvatarFetcherService } from './avatar-fetcher.service';

describe('AvatarFetcherService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AvatarFetcherService]
    });
  });

  it('should be created', inject([AvatarFetcherService], (service: AvatarFetcherService) => {
    expect(service).toBeTruthy();
  }));
});
