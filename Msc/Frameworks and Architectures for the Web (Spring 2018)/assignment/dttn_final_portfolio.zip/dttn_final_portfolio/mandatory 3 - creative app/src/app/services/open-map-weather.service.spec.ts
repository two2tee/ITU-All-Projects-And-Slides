import { TestBed, inject } from '@angular/core/testing';

import { OpenMapWeatherService } from './open-map-weather.service';
describe('OpenMapWeatherService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OpenMapWeatherService]
    });
  });

  it('should be created', inject([OpenMapWeatherService], (service: OpenMapWeatherService) => {
    expect(service).toBeTruthy();
  }));
});
