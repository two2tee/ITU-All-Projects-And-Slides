// https://robohash.org/
// This service is resposible of fetching avatar images
// and generating a unqiue name for each location
// We use base64 to generate a "robot" like name based on input.
// base64 also ensures that the name is always the same for a given input
// eg the string Auckland would always be the base64 encoded value of "Auckland"

import { Injectable } from '@angular/core';

@Injectable()
export class AvatarFetcherService {

  constructor() { }

  getAvatarImageUrl(input: string): string {
    return `https://robohash.org/${input}.png`;
  }

  getNotFoundAvatarUrl(input: string) {
    return `https://robohash.org/${input}.png?set=set2`;
  }

  getAvatarName(input: string): string {
    // encode with base64
    let name = btoa(input);
    name = name.slice(0, 1).toUpperCase() + '-' + name.slice(1, 4);
    return name;
  }

}
