//This module is responsible for showing wheather details
//of the current whether passed bt the parent module - weather.component

import { Component, OnInit, Input } from '@angular/core';
import { Weather } from '../models/weather';
import { SearchModel } from '../models/searchModel';

@Component({
  selector: 'app-weather-details',
  templateUrl: './weather-details.component.html',
  styleUrls: ['./weather-details.component.css']
})
export class WeatherDetailsComponent implements OnInit {

  //@input denotes that these fields are set by the parent module
  @Input() currentWeather: Weather;
  @Input() searchModel: SearchModel;

  constructor() { }

  ngOnInit() { }

    getTemperature(): string {
    if (this.searchModel.selectedTemperature === 'celsius') {
      return this.currentWeather.getTemperatureCelsius() + ' celsius';
    }
    else {
      return this.currentWeather.getTemperatureFahrenheit() + ' fahrenheit';
    }
  }

    getWindDirectionState(): string {
    const dir = this.currentWeather.windDeg; // Degrees converted to labels
    if (dir >= 0 && dir <= 20 || dir > 315) { return 'east'; }
    if (dir >= 20 && dir < 70) { return 'northeast'; }
    if (dir >= 70 && dir < 110) { return 'north'; }
    if (dir >= 110 && dir < 160) {return  'northwest'; }
    if (dir >= 160 && dir < 200) {return  'west'; }
    if (dir >= 200 && dir < 250) {return  'southwest'; }
    if (dir >= 250 && dir < 290) {return  'south'; }
    if (dir >= 290 && dir < 315) {return  'southeast'; }
  }

    getCloudDensityState() {
    if (this.currentWeather.cloudCoverage > 0) {
      return 'lightly clouded';
    }
    else if (this.currentWeather.cloudCoverage >= 25) {
      return 'clouded';
    }
    else if (this.currentWeather.cloudCoverage >= 50) {
      return 'overcast';
    }
    return 'clear';
  }


}
