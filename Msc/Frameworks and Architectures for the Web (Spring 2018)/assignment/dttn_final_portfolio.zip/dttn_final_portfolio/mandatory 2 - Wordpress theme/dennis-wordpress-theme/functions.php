<?php
add_theme_support( 'post-thumbnails' );
@ini_set( 'upload_max_size' , '64M' );
@ini_set( 'post_max_size', '64M');
@ini_set( 'max_execution_time', '300' );

function portfolio_script_enqueue(){
    wp_enqueue_style( 'mainstyle', get_template_directory_uri() . '/css/portfoliostyle.css',array(),'1.0.0', 'all');
}

function getHome($extension){
    if(is_home()){
        return $extension;
    }
    else{
        $url = get_site_url();
        return  $url.'/'.$extension;
    }
}

function getSiteTitle(){
    $title = bloginfo( 'name' );
    if(isNullOrEmptyString($title)){
        return 'Awesome';
    }
    return "{". $title. "}";
}

function getSiteDescription(){
    $description = bloginfo( 'description' );
    if(isNullOrEmptyString($title)){
        return '';
    }
    return "[". $description. "]";
}

function isNullOrEmptyString($input){
    return (!isset($input) || trim($input)==='');
}

add_action('wp_enqueue_scripts', 'portfolio_script_enqueue');
?>