<?php get_header(); ?>
<section class="featured">
    <div class="container">
        <div class="row">
            <div class="text-block col-sm-12">
                <h2>Hi, I'm</h2>
                <h1>
                    { <?php getSiteTitle(); ?> }
                </h1>
                <p><?php getSiteDescription(); ?></p>
                <a href="<?php echo get_page_link(5); ?>" class="hire-me">
                    <button class="button call-to-action">
                        Hire me
                    </button>
                </a>
            </div>
            <div id="headersocial" class="social-links">
                <ul class="navlist">
                    <li><a href="https://www.facebook.com"><img class="socialimg zoom" border="0" alt="Facebook"
                                                                src="<?php echo get_stylesheet_directory_uri(); ?>/img/Facebook.png"></a></li>
                    <li><a href="https://www.linkedin.com"><img class="socialimg zoom" border="0" alt="Linkedin"
                                                                src="<?php echo get_stylesheet_directory_uri(); ?>/img/Linkedin.png"></a></li>
                    <li><a href="https://www.Instagram.com"><img class="socialimg zoom" border="0" alt="Instagram"
                                                                 src="<?php echo get_stylesheet_directory_uri(); ?>/img/Instagram.png"></a></li>
                    <li><a href="https://www.github.com"><img class="socialimg zoom" border="0" alt="Github"
                                                              src="<?php echo get_stylesheet_directory_uri(); ?>/img/Github.png"></a></li>
                </ul>
            </div>
            <img id="robotimg" src="<?php echo get_stylesheet_directory_uri(); ?>/img/Robo.png">
        </div>
    </div>
</section>
<section class="content">
    <a name="skills" id="skills"/>
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="main-content-item col-lg-6 backend-sub">
                    <h1>Backend</h1>
                    <div class="container">
                        <div class="row">
                            <div class="skills-item col-12">
                                <img class='skills_image zoom' border="0" alt="csharp" src="<?php echo get_stylesheet_directory_uri(); ?>/img/csharp.png">
                                <img class='skills_image zoom' border="0" alt="java" src="<?php echo get_stylesheet_directory_uri(); ?>/img/java.png">
                            </div>
                        </div>
                        <div class="row">
                            <div class="skills-item col-12">
                                <img class='skills_image zoom' border="0" alt="scala" src="<?php echo get_stylesheet_directory_uri(); ?>/img/scala.png">
                                <img class='skills_image zoom' border="0" alt="mysql" src="<?php echo get_stylesheet_directory_uri(); ?>/img/sql.png">
                                <img class='skills_image zoom' border="0" alt="go" src="<?php echo get_stylesheet_directory_uri(); ?>/img/go.png">
                            </div>
                        </div>
                    </div>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur
                        adipiscing elit, sed do eiusmod tempor
                        incididunt ut labore et dolore magna aliqua.
                        Ut enim ad minim veniam, quis nostrud exercitation
                        ullamco laboris nisi ut aliquip ex ea commodo
                        consequat. Duis aute irure dolor in reprehenderit
                        in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                        Excepteur sint occaecat cupidatat non proident, sunt in culpa
                        qui officia deserunt mollit anim id est laborum
                    </p>

                </div>
                <div class="main-content-item col-lg-6 frontend-sub">
                    <h1>Frontend</h1>
                    <div class="container">
                        <div class="row">
                            <div class="skills-item col-12">
                                <img class='skills_image zoom' border="0" alt="css" src="<?php echo get_stylesheet_directory_uri(); ?>/img/css.png">
                                <img class='skills_image zoom' border="0" alt="html" src="<?php echo get_stylesheet_directory_uri(); ?>/img/html.png">
                            </div>
                        </div>
                    </div>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur
                        adipiscing elit, sed do eiusmod tempor
                        incididunt ut labore et dolore magna aliqua.
                        Ut enim ad minim veniam, quis nostrud exercitation
                        ullamco laboris nisi ut aliquip ex ea commodo
                        consequat. Duis aute irure dolor in reprehenderit
                        in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                        Excepteur sint occaecat cupidatat non proident, sunt in culpa
                        qui officia deserunt mollit anim id est laborum
                    </p>

                </div>
            </div>
            <div class="row professional-sub custom-header">
                    <h1>Professional Experience</h1>
            </div>
            <div class="row professional-sub">
                <div class="container">
                    <div class="row">
                    <div class="col-md-2"></div> <!--Padding-->
                    <div class="main-content-item col-md-8">
                        <figure class=" standard-right-caption">
                            <img class="standard-figure-img hideable" src="<?php echo get_stylesheet_directory_uri(); ?>/img/rb.png" alt="save the children"/>
                            <figcaption class="left">
                                <p class="work-company">
                                    Save the Children
                                </p>
                                <p class="work-position">
                                    <strong>Software Engineer</strong>, <i>since 2017</i>
                                </p>
                                <p class="work-location">
                                    <strong>Copenhagen - Denmark</strong>
                                </p>
                                <p class="work-description">
                                    Every day, more than millions of children are suffering. By improving,
                                    implementing and automating business processes, Save the Children can
                                    in return aid more children in need.
                                </p>
                            </figcaption>
                         </figure>
                        <div class="col-md-2"></div> <!--Padding-->
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2"></div> <!--Padding-->
                    <div class="main-content-item col-md-8">
                        <figure class=" standard-right-caption">
                            <img class="standard-figure-img hideable" src="<?php echo get_stylesheet_directory_uri(); ?>/img/itu.png" alt="ITU"/>
                            <figcaption class="left">
                                <p class="work-company">
                                    IT-University of Copenhagen
                                </p>
                                <p class="work-position">
                                    <strong>TA in Software Development</strong>, <i>in 2017</i>
                                </p>
                                <p class="work-location">
                                    <strong>Copenhagen - Denmark</strong>
                                </p>
                                <p class="work-description">
                                        As a TA, I will help the students understand concepts during tutorials
                                        and give feedback on their work. This requires that I know how to
                                        formulate and explain knowledge to a diverse set of people.
                                </p>
                            </figcaption>
                        </figure>
                    <div class="col-md-2"></div> <!--Padding-->
                    </div>
                 </div>
                </div>
            </div>
            <div class="row academic-sub custom-header">
                <h1>Academic Experience</h1>
            </div>
            <div class="row academic-sub">
                <div class=" main-content-item col-lg-4">
                    <figure class="school-badge">
                        <img class="standard-figure-img zoom" src="<?php echo get_stylesheet_directory_uri(); ?>/img/Level 1.png" alt="bsc"/>
                        <figcaption>
                            <p class="school-type">
                                Bachelor's Degree
                            </p>
                            <p class="school-place">
                                IT-University of Copenhagen
                            </p>
                            <p class="school-line">
                                Software Development
                            </p>
                            <p class="school-year">
                                2014-2017
                            </p>
                        </figcaption>
                    </figure>
                </div>
                <div class="main-content-item col-lg-4 academic-sub">
                    <figure class="school-badge">
                        <img class="standard-figure-img zoom" src="<?php echo get_stylesheet_directory_uri(); ?>/img/Level 2.png" alt="msc"/>
                        <figcaption>
                            <p class="school-type">
                                Bachelor's Degree
                            </p>
                            <p class="school-place">
                                IT-University of Copenhagen
                            </p>
                            <p class="school-line">
                                Software Development
                            </p>
                            <p class="school-specialization">
                                Business Analytics
                            </p>
                            <p class="school-year">
                                2014-2017
                            </p>
                        </figcaption>
                    </figure>
                    </div>
                <div class="main-content-item col-lg-4 academic-sub">
                    <figure class="school-badge">
                        <img class="standard-figure-img zoom" src="<?php echo get_stylesheet_directory_uri(); ?>/img/Level Abroad.png" alt="abroad"/>
                        <figcaption>
                            <p class="school-type">
                                Bachelor's Degree
                            </p>
                            <p class="school-place">
                                IT-University of Copenhagen
                            </p>
                            <p class="school-line">
                                Software Development
                            </p>
                            <p class="school-year">
                                2014-2017
                            </p>
                        </figcaption>
                    </figure>
                </div>
            </div>
            <div class="row projects-sub custom-header">
                    <a name="projects" id="projects"/>
                    <h1>Projects</h1>
            </div>
            <div class="row projects-sub">
                    <div class="container">
                    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                        <div class="row">
                            <div class="main-content-item project">
                                <figure class=" standard-right-caption">
                                    <img class="standard-figure-img hideable" src="<?php the_post_thumbnail_url(); ?>" alt="save the children"/>
                                    <figcaption class="left">
                                        <p class="project-title">
                                                <?php the_title(); ?>
                                        </p>
                                        <p class="project-platform">
                                                <?php $cat = get_the_category(); echo $cat[0]->cat_name; ?>
                                        </p>
                                        <p class="project-description">
                                                <?php the_excerpt(); ?>
                                        </p>
                                        <a href="<?php echo get_permalink(); ?>">Read More</a>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php endif; ?>
                    </div>
                </div>
            <div class="row about-sub custom-header">
                <a name="about" id="about"/>
                <h1>When I != { code }</h1>
            </div>
            <div class="row about-sub">
                <div class="col-md-2"></div> <!--Padding-->
                <div class="main-content-item col-lg-4">
                    <figure class="school-badge">
                        <img class="standard-figure-img zoom" src="<?php echo get_stylesheet_directory_uri(); ?>/img/piano.png" alt="piano"/>
                        <figcaption>
                            <p class="hobby-type">
                                Piano: Jazz, Ballads, Classic
                            </p>
                            <p class="hobby-level">
                                Level 100
                            </p>
                            <p class="hobby-description">
                                I love playing on my piano. So much that<br/>
                                I've been doing so for 20+ years.<br/>
                                Music has always been a part of my life!
                            </p>
                        </figcaption>
                    </figure>
                </div>
                <div class="main-content-item col-lg-4">
                    <figure class="school-badge">
                        <img class="standard-figure-img zoom" src="<?php echo get_stylesheet_directory_uri(); ?>/img/dance.png" alt="dance"/>
                        <figcaption>
                            <p class="hobby-type">
                                Salsa: Advance level
                            </p>
                            <p class="hobby-level">
                                Level 80
                            </p>
                            <p class="hobby-description">
                                I dance a lot of Salsa and I go social <br/>
                                dancing every now and then.<br/>
                                Especially after hours of <i>'Code smashing'</i>
                            </p>
                        </figcaption>
                    </figure>
                </div>
                <div class="col-md-2"></div> <!--Padding-->
            </div>
            <div class="row grass">
                <img id="tree" src="<?php echo get_stylesheet_directory_uri(); ?>/img/tree.png" alt="tree"/>
                <div class="main-content-item col-12"></div> <!--Is this hacky to create grass-->
            </div>
        </div>
    </div>
</section>
<section class="call-to-action">
    <div class="container">
        <div class="row">
            <div class="text-block col-sm-12">
                <p id="callheader">Interested?</p>
                <a href="<?php echo get_page_link(5); ?>" class="hire-me">
                    <button class="button call-to-action"> Hire me</button>
                </a>
                <div class="social-links">
                    <ul class="navlist">
                        <li><a href="https://www.facebook.com"><img class="socialimg zoom" border="0" alt="Facebook" src="<?php echo get_stylesheet_directory_uri(); ?>/img/Facebook.png"></a></li>
                        <li><a href="https://www.linkedin.com"><img class="socialimg zoom" border="0" alt="Linkedin" src="<?php echo get_stylesheet_directory_uri(); ?>/img/Linkedin.png"></a></li>
                        <li><a href="https://www.Instagram.com"><img class="socialimg zoom" border="0" alt="Instagram"src="<?php echo get_stylesheet_directory_uri(); ?>/img/Instagram.png"></a></li>
                        <li><a href="https://www.github.com"><img class="socialimg zoom" border="0" alt="Github" src="<?php echo get_stylesheet_directory_uri(); ?>/img/Github.png"></a></li>
                    </ul>
                </div>
                <img id="letter" src="<?php echo get_stylesheet_directory_uri(); ?>/img/letter.png" alt="letter"/>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>
