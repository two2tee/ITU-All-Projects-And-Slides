<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php getSiteTitle(); ?>- Portfolio</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">          
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"/></script>
    <?php wp_head(); ?>
</head>
<body>
<header class="site-header">
    <a name="home" id="home">


    <nav class="navbar navbar-toggleable-sm navbar-light">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="<?php echo home_url(); ?>" >
            <img class="brand-logo" src="<?php echo get_stylesheet_directory_uri(); ?>/img/Logosm.png" alt="dennis Product Logo"/>
            <?php getSiteTitle(); ?>
        </a>
        <div id="navbarSupportedContent" class="primary horizontal collapse navbar-collapse">
            <ul class="navigations navbar-nav">
                <li class="nav-item">
                    <a href="<?php echo getHome('#home'); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo getHome('#skills');?>">Skills</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo getHome('#projects');?>">Projects</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo home_url('#about'); ?>">About</a>
                </li>
                <?php wp_list_pages( '&title_li=' ); ?>
            </ul>
        </div>
    </nav>
</header>