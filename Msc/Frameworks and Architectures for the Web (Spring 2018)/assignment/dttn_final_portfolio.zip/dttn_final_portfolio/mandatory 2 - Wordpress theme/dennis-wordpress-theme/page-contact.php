<?php get_header(); ?>
<section class="page-content">
    <div class="flex-container flex-row">
        <div class="item">
            <h1>Contact me</h1>
            <div class="form-container">
                    <form action=""><!-- NO FUNCTIONALITY YET -->
                      <input class="form-input" type="text" id="fname" name="firstname" placeholder="name">
                      <input class="form-input" type="text" id="lname" name="lastname" placeholder="mail">
                      <textarea class="form-input" id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>
                      <input class="button form-input" type="submit" value="Submit">
                    </form>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>
