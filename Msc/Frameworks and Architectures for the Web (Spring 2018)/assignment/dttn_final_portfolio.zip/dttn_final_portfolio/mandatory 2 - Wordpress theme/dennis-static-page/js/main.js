$(document).ready(function(){ //wait for all has been loaded
    // Add smooth scrolling to all links
    $("a").on('click', function(event) {
        //TODO FIX SMOOTH SCROLL
    });
});


