package source.View;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.controlsfx.control.action.Action;
import org.controlsfx.dialog.Dialog;
import org.controlsfx.dialog.Dialogs;
import source.Model.LineObject;

import java.io.File;
import java.util.ArrayList;

/**
 * This class is responsible for handling view methods.
 * Created by Dennis Thinh Tan Nguyen 04-02-2015.
 */
public class PrimaryView extends Application{
    //View inits
    private static boolean launched =false;
    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("PrimaryView.fxml"));
        primaryStage.setResizable(true);
        primaryStage.setTitle("Line drawer X PRO");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    public static void launchApp(String[]arg) {
        if (!launched) {
            launch(arg);
            launched = true;
        }

        else System.out.println("Already running");
    }

    //Fields
    private GraphicsContext gc;

    //Methods

    /**
     * Draws image with lines.
     * The coordinates are retrieved from LineObjects
     * @param lines
     */
    public void draw(ArrayList<LineObject> lines) {
        clearCanvas();

        for (LineObject line : lines)
        {
            gc.setLineCap(StrokeLineCap.BUTT);    //Uses butt cap to stroke lines

            //Draw thick black line as stroke
            gc.setLineWidth(2);
            gc.setStroke(Color.BLACK);
            gc.strokeLine(line.getX1(), line.getY1(), line.getX2(), line.getY2());

            //Draw a thin overlapping white line as fill.
            gc.setLineWidth(1);
            gc.setStroke(Color.WHITE);
            gc.strokeLine(line.getX1(),line.getY1(),line.getX2(),line.getY2());
        }

    }

    /**
     * Change color of fill and stroke
     * @param fill
     * @param stroke
     * @param lineList
     */
    public void ChangeColor(Color fill, Color stroke,ArrayList<LineObject> lineList)
    {
        gc.setFill(fill);
        gc.setStroke(stroke);
        draw(lineList);
    }

    /**
     * Clears the canvas
     */
    public void clearCanvas()
    {
        gc.clearRect(0,0,970,680);
        gc.setFill(Color.WHITE);
        gc.fillRect(0,0,970,680);
    }


    /**
     * Method used to pan the canvas
     * NOTE: This doesn't work
     * @param x
     * @param y
     * @param lineList
     */
    public void moveCanvas( double x, double y,ArrayList<LineObject> lineList)
    {
        clearCanvas();
        //gc.translate(x,y);
        //Affine AffineSet = gc.getTransform();
        //AffineSet.createConcatenation(Transform.translate(x,y));
        //gc.transform(AffineSet);
        draw(lineList); //Dynamic change

    }


    /**
     * Zoom in by increasing scale
     * @param lineList
     */
    public void zoomIn(ArrayList<LineObject> lineList)
    {
            double zoomScale = 1.05;
            gc.scale(zoomScale, zoomScale);
            draw(lineList); //Dynamic change
    }

    /**
     * Zoom out by decreasing scale
     * @param lineList
     */
    public void zoomOut(ArrayList<LineObject> lineList)
    {
            double zoomScale = 0.95;
            gc.scale(zoomScale, zoomScale);
            draw(lineList); //Dynamic change
    }



    /**
     * Disable colour by setting colour values to black and white
     */
    public void disableColor()
    {
        gc.setFill(Color.WHITE);
        gc.setStroke(Color.BLACK);
    }


    /**
     * Universal method to display a dialog box with a message
     * It can either be an info type or error type. We are using controlFX java libraries to show
     * the dialog boxes
     * credits: http://fxexperience.com/controlsfx/
     *
     * @param type ("error" // "info" // "confirmation")
     * @param m message to display.
     */
    public boolean DialogMessages(String type, String m)
    {
        switch (type) {
            case "error":  Dialogs.create()
                    .owner(new Stage())
                    .title("Error Message")
                    .message(m)
                    .showError();
                break;
            case "info": Dialogs.create()
                    .owner(new Stage())
                    .title("Information")
                    .message(m)
                    .showInformation();
                break;
            case "confirmation":
                Action response = Dialogs.create().create()
                        .owner(new Stage())
                        .title("Confirmation")
                        .message(m)
                        .actions(Dialog.ACTION_YES,Dialog.ACTION_NO)
                        .showConfirm();

                if (response == Dialog.ACTION_YES)
                {
                    // ... user chose YES
                    return true;
                } else {
                    // ... user chose NO
                    return false;
                }
        }
        return false;
    }

    /**
     * Method to locate an input file. A fileChooser dialog box will be shown
     * to the user, so he can locate a specific input file
     * @param lastUsedFile last used file location
     */
    public File locateFile(File lastUsedFile)
    {
        FileChooser fileChooser = new FileChooser();


        //Open directory from existing directory
        if(lastUsedFile != null){
            File existDirectory = lastUsedFile.getParentFile();
            fileChooser.setInitialDirectory(existDirectory);
        }

        //Setting extension filters.
        FileChooser.ExtensionFilter filter = new FileChooser.ExtensionFilter("TxT files (*.txt)", "*.txt");
        fileChooser.getExtensionFilters().add(filter);

        //Display dialog
        fileChooser.setTitle("Select map file");
        File file = fileChooser.showOpenDialog(new Stage());

        return file;

    }

    /**
     * retrieve and set the Graphics context which is parsed
     * by the controller.
     * @param gcArg - Graphics Context
     */
    public void setGC(GraphicsContext gcArg)
    {
        gc = gcArg;
    }


}
