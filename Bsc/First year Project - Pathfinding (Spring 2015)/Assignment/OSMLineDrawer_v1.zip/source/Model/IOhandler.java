package source.Model;

import javafx.scene.shape.Line;

import java.io.*;
import java.util.ArrayList;

/**
 * Created by Dennis Thinh Tan Nguyen 04-02-2015.
 */
public class IOhandler {

    private static File fileUsed;
    //File methods

    /**
     * This method will receive a file as parameter and store it in the global field.
     * This method is used when you locate and select a file with address entries
     *
     * @param selected file with address entries
     */
    public void setFile(File selected) {
        fileUsed = null;
        fileUsed = selected;

        if (fileUsed != null)
            System.out.println(fileUsed.getName() + " was selected");

        else
            System.out.println("File could not be selected");
    }

    /**
     *  The method reads the map file(txt file), saves them in LineObjects, which will
     *  be added and returned in an ArrayList
     * @param filename
     * @return
     */
    public ArrayList<LineObject> readFile(File filename)
    {
        ArrayList<LineObject> lineList = new ArrayList<>();
        long time = System.nanoTime();
        try (BufferedReader input =
             new BufferedReader(new FileReader(filename))) {

            for (String line = input.readLine() ; line != null ;
                 line = input.readLine()) {
                String[] words = line.split(" ");
                lineList.add(new LineObject(
                        Double.parseDouble(words[0]),
                        Double.parseDouble(words[1]),
                        Double.parseDouble(words[2]),
                        Double.parseDouble(words[3])));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.printf("Model load time: %d ms\n",
                (System.nanoTime() - time) / 1000000);
        return lineList;
    }

    /**
     * This method returns the< last loaded file.
     * @return last loaded file
     */
    public File getFile() {
        return fileUsed;
    }

}
