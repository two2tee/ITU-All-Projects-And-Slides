package source.Model;

import javafx.collections.ObservableList;
import javafx.scene.shape.Line;

import java.awt.geom.Line2D;
import java.io.*;
import java.util.ArrayList;

/**
 * This class is the model and is responsible for returning lineObjects which
 * will be used to draw the map.
 * Created by Dennis Thinh Tan Nguyen 04-02-2015.
 */
public class PrimaryModel {

    IOhandler iOhandler;
    ArrayList<LineObject> lineList;

    public PrimaryModel(){
        iOhandler = new IOhandler();
        lineList = new ArrayList<>();
    }

    /**
     * get the current stored coordinations
     *
     * @return address file
     */
    public void readFile(File filename)
    {
        iOhandler.setFile(filename); //setting file
        lineList = iOhandler.readFile(filename);

    }

    /**
     * Returns last loadaed file
     * @return last loaded file
     */
    public File getLastUsed() {
        return iOhandler.getFile();
    }

    /**
     * Returns the loaded list with LineObjects
     * @return
     */
    public ArrayList<LineObject> getLineList(){
        return lineList;
    }

    /**
     * Clears the list of loaded lineObjects
     */
    public void clearList(){
        lineList.clear();
    }
}


