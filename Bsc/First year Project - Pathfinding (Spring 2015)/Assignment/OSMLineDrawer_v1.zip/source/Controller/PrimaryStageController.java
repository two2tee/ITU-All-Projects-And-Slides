package source.Controller;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.ColorPicker;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.paint.Color;
import source.Model.LineObject;
import source.Model.PrimaryModel;
import source.View.PrimaryView;

import java.io.File;
import java.util.ArrayList;

/**
 * This class is the controller and handles the dataflow between model and view
 */
public class PrimaryStageController {

    //Fields
    @FXML
    private ColorPicker colourPickerFill;

    @FXML
    private ColorPicker colourPickerStroke;

    @FXML
    private Canvas canvas;

    private static boolean isToggleColour;
    private static double pressedX, pressedY;
    private PrimaryModel model;
    private PrimaryView view;


    //Constructor
    public PrimaryStageController(){
        model = new PrimaryModel();
        view = new PrimaryView();
    }

    //initializer
    @FXML
    private void initialize()
    {
        //Init canvas
        view.setGC(canvas.getGraphicsContext2D());
        view.clearCanvas();

        //New color picker
        colourPickerStroke = new ColorPicker(Color.BLACK);
        colourPickerFill = new ColorPicker(Color.WHITE);
    }

    //Methods

    /**
     * Method used to draw the map
     */
    @FXML
    private void draw()
    {
        if(!isToggleColour){view.disableColor();}
        view.draw(model.getLineList());
    }

    /**
     * Retrieves the color value of colorPicker and parse it to View;
     * NOTE: The method does not work yet, because .getValue keeps returning the colour white.
     */
    @FXML
    private void changeColor()
    {
        view.ChangeColor(colourPickerFill.getValue(), colourPickerStroke.getValue(), model.getLineList());
        view.DialogMessages("info", "Please note that the color picker doesn't work yet");
    }



    /**
     * Method used to change status of color being enabled or disabled
     */
    @FXML
    private void toggleColour()
    {
        isToggleColour = !isToggleColour;
        view.DialogMessages("info", "Please note that the color picker doesn't work yet");
    }

    /**
     * Clears the canvas
     */
    @FXML
    private void clearCanvas(){
        view.clearCanvas();
    }


    /**
     * Method handles the zoom function, by scaling the image and canvas.
     * NOTE: This is not the right way to do this
     * @param event
     */
    @FXML
    private void zoom(ScrollEvent event)
    {
        ArrayList<LineObject> lineList = model.getLineList();
        if(!lineList.isEmpty())
        {
            if (event.getDeltaY() < 0) {
                if (canvas.getWidth() > 970) ;
                {
                    view.zoomOut(lineList); //zoom out
                    canvas.setHeight(canvas.getHeight() / 1.05);
                    canvas.setWidth(canvas.getWidth() / 1.05);
                }
            } else if (canvas.getWidth() < 4730) {
                view.zoomIn(lineList); //zoom in
                canvas.setHeight(canvas.getHeight() * 1.05);
                canvas.setWidth(canvas.getWidth() * 1.05);
                System.out.println(canvas.getHeight() + " x " + canvas.getWidth());
            } else System.out.println("NO MOAR ZOOM");
        }
        else view.DialogMessages("info", "No maps are loaded");

    }


    // PAN NOT WORKING YET -----------------

    /**
     * Pans the canvas
     * THIS DOESN'T WORK
     * @param event
     */
    @FXML
    private void pan(MouseEvent event)
    {
        System.out.println(event.getSceneX()+" "+event.getSceneY());
        view.moveCanvas(event.getSceneX(), event.getSceneY(),model.getLineList());
        event.consume();
    }

    /**
     * Retrieves the mouse coordinates
     * @param event
     */
    @FXML
    private void getMouseCoords(MouseEvent event)
    {
            pressedX = event.getX();
            pressedY = event.getY();
    }

 //------------------------------------------


    /**
     * Terminates the program
     */
    @FXML
    private void close(){
        System.exit(0);
    }

    /**
     * This method loads a file with coordinates used to draw the map
     */
    @FXML
    private void loadMap()
    {
        model.clearList();
        File lastUsed =  model.getLastUsed(); //IoHandler.getFile: used to open directory of last opened file
        File locatedFile = view.locateFile(lastUsed);

        if(locatedFile!= null) //in case if user press chancel
        {
            model.readFile(locatedFile);
            draw();
        }
    }

}
