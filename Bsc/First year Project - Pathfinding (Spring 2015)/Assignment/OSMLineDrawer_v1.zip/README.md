Linedrawer X PRO-Cheap
==========


---- HOW TO USE -----
- HOW TO LOAD A MAP -
 - PRESS THE LOAD BUTTON at the lower right corner.
 - Locate a map file
 - Press load

- HOW TO ZOOM -
 - Scroll forward with the mouse wheel to zoom in
 - Scroll backwards with the mouse wheel to zoom out.

----- FEEDBACK -----
Der er to ting som jeg gerne vil have hjælp/feedback til:

    - 1: Jeg kan ikke helt få lavet en pan funktion med javaFX. Jeg har prøvet flere forskellige
    metoder og min nuværende virker slet ikke. Jeg har søgt på flere forskellige sider, men det ser ud til
    at jeg ikke kan finde et konkret svar som netop dækker dette.

    Derfor er jeg kommet frem til en meget dårlig hacks metode, som udvider mit canvas efterhånden
    som man zoomer ud. Da canvaset er wrapped i en scrollPane, så kan man godt "panorere" kortet
    med scrollpanelets scrollbar, netop fordi canvaset er større end panelet.

    Dette er en meget dårlig løsning som jeg ikke helt ved hvordan man kan gøre bedre...



         LOKATION: PrimaryView klasse - Linje 105-112

      public void moveCanvas( double x, double y,ArrayList<LineObject> lineList)
        {
           clearCanvas();
           gc.translate(x,y);                       //gc = GraphicalContent
           Affine AffineSet = gc.getTransform();
           AffineSet.createConcatenation(Transform.translate(x,y));
           gc.transform(AffineSet);
           draw(lineList); //Dynamic change
         }


         LOKATION : PrimaryStageController - Linje: 137-154

        @FXML
           private void pan(MouseEvent event)
           {
               view.moveCanvas(event.getSceneX(), event.getSceneY(),model.getLineList());
               event.consume();
           }


           @FXML
           private void getMouseCoords(MouseEvent event)
           {
                   pressedX = event.getX();
                   pressedY = event.getY();
           }






    - 2: Min colorPicker som jeg har implementeret virker ikke korret.
    problemet er at uanset hvilken farve jeg vælger, så retunere den altid hvid. eg: colourPickerFill.getValue()
    Jeg ved ikke om det er fordi jeg initialiserer koden forkert i controlleren eller om det er en bug i getValue


            LOKATION :PrimaryStageController : Linje 73-77
      @FXML
        private void changeColor()
        {
            view.ChangeColor(colourPickerFill.getValue(), colourPickerStroke.getValue(), model.getLineList());
        }





