Linedrawer X PRO-Cheap
==========


---- HOW TO USE -----
- HOW TO LOAD A MAP -
 - PRESS THE LOAD BUTTON at the lower right corner.
 - Locate a map file
   - Zip file or OSM file (txt file does not work for now)
 - Press load


//NOT WORKING AT THE MOMENT
- HOW TO ZOOM -
 - Scroll forward with the mouse wheel to zoom in
 - Scroll backwards with the mouse wheel to zoom out.

//NOT WORKING AT THE MOMENT
- HOW TO PAN -
 - Drag the map with the mouse to pan the canvas



----- FEEDBACK -----
Der er en ting som jeg gerne vil have feedback til

    - 1: Jeg kan ikke farvelægge grønne arealer eg. parker. (Jeg har også andre dele som ikke kan farvelægges men jeg tror at løsningen er den samme)

    Jeg har i min OSMhandler (Den indre klasse) kaldet denne kodestykke hver gang sax parseren støder på k = natural og v = park

 		Lokation:
 		Klasse: IOHandler --> OSMHandler
 		Linje: 368 - 370

       	if(atts.getValue("k").equals("natural") && atts.getValue("v").equals("park"))
                isGreenArea = true;

    Fremgangsmåden er den samme som Troels med hans "Buildings", hvor jeg i dette tilfælde, indsætter way objekter i en array liste henholdsvis kun for "GreenAreas"

    Det underlige er at når jeg så prøver at tegne det, så sker der ikke noget og jeg kan simpelhen ikke se problemet. Jeg kan farvelægge vand, bygninger osv men ikke 
    parker.



	Lokation:
 		Klasse: PrimaryView
 		Linje: 104 - 146

	private void drawLines(ArrayList<Way>lines, int type)
	{
		for (Way road : lines)
		{
			ArrayList<Coordinate> coords = road.getWay(); //Retrieving coords

			gc.beginPath();

				for (Coordinate coord : coords)
				{
					gc.lineTo(coord.getX(), coord.getY());
				}

          
                switch (type) {
                 	(...) //kodeudsnit
                    case 5 :
                        drawGreenArea();
                        break;
                }

 			gc.closePath();
		}
	}


	Lokation:
 		Klasse: PrimaryView
 		Linje: 204 - 211

    private void drawGreenArea()
    {
   		if (isToggleColour) gc.setFill(Color.FORESTGREEN);
   		else gc.setFill(Color.LIGHTGREEN);
   		gc.setStroke(Color.BLACK);

   		gc.fill();
    	gc.stroke();
    }







