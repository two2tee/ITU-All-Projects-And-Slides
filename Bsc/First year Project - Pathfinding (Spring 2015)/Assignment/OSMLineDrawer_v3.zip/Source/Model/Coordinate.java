package source.Model;

/**
 * This class creates an instance containing a single set of coordinates  
 * Created by Dennis Thinh Tan Nguyen 17-02-2015.
 */
public class Coordinate {
    double x,y;
    
    public Coordinate(double x, double y)
    {
        this.x = x;
        this.y = y;
    }

    //Getter

    /**
     * Retrieves the x coordinate 
     * @return x coordinate
     */
    public double getX() {
        return x;
    }
    
    /**
     * Retrieves the y coordinate 
     * @return y coordinate
     */
    public double getY(){
            return y;
        }

}
