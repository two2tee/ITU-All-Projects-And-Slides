package source.Model;

import java.util.ArrayList;

/**
 * This class creates an instance containing an ArrayList with coordinates
 * The instance is a representation of a path with n numbers of coordinates 
 * Created by Dennis Thinh Tan Nguyen 07-02-2015.
 */
public class Way {
   ArrayList<Coordinate> coordinates;

    public Way(double x, double y)
    {
        coordinates = new ArrayList<Coordinate>();
        coordinates.add(new Coordinate(x,y));
    }

    /**
     * Add more coordinates to the object
     * @param x
     * @param y
     */
    public void addMoreCoords(double x, double y)
    {
        coordinates.add(new Coordinate(x,y)); 
    }

    /**
     * Returns the arraylist that contains the coordiantes 
     * @return Arraylist with coordinates
     */
    public ArrayList<Coordinate> getWay()
    {
        return coordinates;
    }

    
    

}
