package source.Model;

import javafx.geometry.BoundingBox;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by Dennis Thinh Tan Nguyen 04-02-2015.
 */
public class PrimaryModel {

    IOhandler iOhandler;
    ArrayList<ArrayList> lines;

	private double minLon;
	private double maxLat;

    /**
     * Constructor
     */
    public PrimaryModel(){
        iOhandler = new IOhandler();
        lines = new ArrayList<>();
    }

    /**
     * Reads and parses the loaded file
     * @return address file
     */
    public void readFile(File filename)
    {
        iOhandler.setFile(filename); //setting file
        iOhandler.readFile(filename);

        lines = iOhandler.getLines();
		maxLat = iOhandler.getMaxLat();
	    minLon = iOhandler.getMinLon();


    }


    /**
     * Retrieve last used file. It's location will be used when you want
     * to load another map
     * @return last used file
     */
    public File getLastUsed() {
        return iOhandler.getFile();
    }

    /**
     * Retrieves an arraylist of road coords
     * @return Arraylist<Way> --> road coords
     */
    public ArrayList<ArrayList> getLines()   {    return lines;   }


    /**
     * Returns the boundingBox
     * @return boundingBox
     */
    public BoundingBox getBoundingBox()     {    return iOhandler.getBBox(); }

	public double getMinLon() {
		return minLon;
	}

	public double getMaxLat() {
		return maxLat;
	}

	/**
     * Clears both arrayList (Buildings and lines)
     */
    public void clearList()
    {
        lines.clear();
    }
}


