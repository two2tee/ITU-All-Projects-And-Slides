package source.Model;

import javafx.geometry.BoundingBox;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.zip.ZipInputStream;

/**
 * Created by Dennis Thinh Tan Nguyen 04-02-2015.
 */
public class IOhandler {


    private File fileUsed;
        //Arraylists with ways
		private ArrayList<Way> mainRoads = new ArrayList<>();
		private ArrayList<Way> minorRoads = new ArrayList<>();
	    private ArrayList<Way> waterWays = new ArrayList<>();
	    private ArrayList<Way> buildings = new ArrayList<>();
		private ArrayList<Way> coastLines = new ArrayList<>();
        private ArrayList<Way> greenArea = new ArrayList<>();
        private ArrayList<Way> greySurface = new ArrayList<>();

	private double minLon; 
	private double maxLat;

    private BoundingBox bbox;
    
    //File methods

    /**
     * This method will receive a file as parameter and store it in the global field.
     * This method is used when you locate and select a file with address entries
     *
     * @param selected file with address entries
     */
    public void setFile(File selected) {
        fileUsed = null;
        fileUsed = selected;

        if (fileUsed != null)
            System.out.println(fileUsed.getName() + " was selected");

        else
            System.out.println("File could not be selected");
    }

    /**
     * Reads an input file with file extension:
     * .osm - .zip - .txt
     * NOTE: txt. does NOT work right now
     * @param filename
     */
    public void readFile(File filename) {
        try {
            String filePath = filename.getCanonicalPath();
            long time = System.nanoTime();

           // if (filePath.endsWith(".txt")) parseTxT(filename); // NEED REFACT

            if (filePath.endsWith(".osm")) parseOSM(filename);
            else if (filePath.endsWith(".zip")) parseZIP(filename);
            else System.err.println("File not recognized");
            System.out.printf("Model load time: %d ms\n", (System.nanoTime() - time) / 1000000);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns current file
     * @return file
     */
    public File getFile() {
        return fileUsed;
    }

    /**
     * Returns an array list arraylists of lines
     * index 0 = MainRoads
     * index 1 = MinorRoads
     * index 2 = buildings
     * index 3 = waterWays
     * index 4 = coastlines
     * index 5 = other
     * index 6 = green area 
     * @return an array list with lines
     */
    public ArrayList getLines() {
	    ArrayList<ArrayList> map = new ArrayList<>();
	    map.add(mainRoads);
	    map.add(minorRoads);
	    map.add(buildings);
	    map.add(waterWays);
	    map.add(coastLines);
        map.add(greenArea);
        return map;
    }

	/**
     * Returns bounding box
     * @return bounding box
     */
    public BoundingBox getBBox(){ return bbox;}

	public double getMinLon() {return minLon;}

	public double getMaxLat() {return maxLat; }

    /*
    public ArrayList parseTxT(File filename) {

        ArrayList<Way> lineList = new ArrayList<>();
        long time = System.nanoTime();
        try (BufferedReader input =
                     new BufferedReader(new FileReader(filename))) {

            for (String line = input.readLine(); line != null;
                 line = input.readLine()) {
                String[] words = line.split(" ");
                lineList.add(new Way(
                        Double.parseDouble(words[0]),
                        Double.parseDouble(words[1]),
                        Double.parseDouble(words[2]),
                        Double.parseDouble(words[3])));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.printf("Model load time: %d ms\n",
                (System.nanoTime() - time) / 1000000);
        return lineList;
    }
*/

    /**
     * Parse a zip file containing an OSM file (XML FILE)
     * @param filename zip file
     */
    public void parseZIP(File filename) {
        fileUsed = filename;
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(new FileInputStream(filename)))) {
            zip.getNextEntry();
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(new OSMHandler());
            reader.parse(new InputSource(zip));


        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (org.xml.sax.SAXException e) {
            e.printStackTrace();
        }
    }

    /**
     * Parse an OSM fil
     * @param filename osm file
     */
    public void parseOSM(File filename) {
        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(new OSMHandler());
            System.out.println(filename.toURI().toString());
            reader.parse(filename.toURI().toString());

        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (org.xml.sax.SAXException e) {
            e.printStackTrace();
        }

    }


    //OSM HANDLER - INNERCLASS
    
    /**
     * This nested inner class is responsible for reading and parsing
     * the right information within  a map file (XML file)
     */
    class OSMHandler extends DefaultHandler {
        
        //Fields
        
        HashMap<Long, Coordinate> map = new HashMap<>();
        Way way;
        boolean isBuilding;
	    boolean isWaterWay;
	    boolean isCoastLine;
	    boolean isMainRoad;
	    boolean isMinorRoad;
        boolean isGreenArea;
        boolean isGreySurface;


        //methods
        
        public void endElement(String uri, String localName, String qName) {
            if (qName.equals("way")) {
                if (isBuilding)
                {
                    buildings.add(way);
                }
                else if(isWaterWay)
                {
                    waterWays.add(way);
                }
	            else if(isCoastLine)
	            {
		            coastLines.add(way);
	            }
	            else if (isMainRoad)
	            {
		            mainRoads.add(way);
	            }
	            else if (isMinorRoad)
	            {
		            minorRoads.add(way);
	            }
                else if (isGreenArea)
                {
                    greenArea.add(way);
                }
                else if (isGreySurface)
                {
                    greySurface.add(way);
                }
            }
        }


        public void startElement(String uri, String localName,
                                 String qName, Attributes atts) {
            if (qName.equals("node"))
            {
                setCoords(atts);
            }
            else if (qName.equals("nd"))
            {
                setLine(atts);
            }
            else if (qName.equals("way"))
            {
                reset();
            }

            else if (qName.equals("bounds"))
            {
                setBounds(atts);
            }
            else if (qName.equals("tag"))
            {
                setTag(atts);
            }
        }


        /**
         * This method will retrieve the latitude and longitude coords
         * of the node, within the XML file/OSM file
         *
         * @param atts  lat and long attribute
         */
        private void setCoords(Attributes atts) {
            float lat = Float.parseFloat(atts.getValue("lat"));
            float lon = Float.parseFloat(atts.getValue("lon"));
            long id = Long.parseLong(atts.getValue("id"));

            Coordinate coord = new Coordinate(lon,lat);
            map.put(id, coord);
        }


        /**
         * This method will draw a line?
         *
         * @param atts
         */
        private void setLine(Attributes atts) {
            long id = Long.parseLong(atts.getValue("ref"));
            Coordinate coord = map.get(id);

            if (coord == null) return;

            if (way == null) //new way
            {
               way = new Way(coord.x,coord.y);
            }
            else //already within a way
            {
                way.addMoreCoords(coord.x,coord.y);
            }
        }

        /**
         * This method will way and isBuilding everytime the parser encounters a
         * new way tag
         */
        private void reset() {
            way = null;
            isBuilding = false;
	        isWaterWay = false;
	        isCoastLine = false;
	        isMainRoad = false;
	        isMinorRoad = false;
            isGreenArea = false;
            isGreySurface = false;
        }

        /**
         * This method retrieves the bounds info of a map
         *
         * @param atts bound attributes
         */
        private void setBounds(Attributes atts) {

            double minlat =
                    Double.parseDouble(atts.getValue("minlat"));
            double minlon =
                    Double.parseDouble(atts.getValue("minlon"));
            double maxlat =
                    Double.parseDouble(atts.getValue("maxlat"));
            double maxlon =
                    Double.parseDouble(atts.getValue("maxlon"));

	        minLon = minlon;
	        maxLat = maxlat;
            bbox = new BoundingBox(minlon, minlat, maxlon - minlon, maxlat - minlat);



        }

        /**
         * This method will set isBuilding to true every time
         * the parser encounters a k take equals to isBuilding.
         * This is used to separate lines and buildings
         *
         * @param atts
         */
        private void setTag(Attributes atts) {
            if (atts.getValue("k").equals("building"))
                isBuilding = true;
	        
            if (atts.getValue("k").equals("waterway")   || atts.getValue("k").equals("natural") && atts.getValue("v").equals("water"))
		        isWaterWay = true;
	        
            if (atts.getValue("k").equals("coastline"))
		        isCoastLine = true;
	        
            if (atts.getValue("k").equals("highway") && atts.getValue("v").equals("primary") ||atts.getValue("v").equals("trunk")||
			        atts.getValue("v").equals("secondary")||atts.getValue("v").equals("tertiary"))
		        isMainRoad = true;

	        if (atts.getValue("k").equals("highway") && !atts.getValue("v").equals("primary") && !atts.getValue("v").equals("trunk") &&
			        !atts.getValue("v").equals("secondary")&& !atts.getValue("v").equals("tertiary"))
		        isMinorRoad = true;

            
            if(atts.getValue("k").equals("natural") && atts.getValue("v").equals("park"))
                   //||atts.getValue("v").equals("wood") || atts.getValue("v").equals("scrub") ||atts.getValue("v").equals("grasslands") )
                isGreenArea = true;
            
            if(atts.getValue("k").equals("surface") &&  atts.getValue("v").equals("asphalt") || atts.getValue("k").equals("surface") &&  atts.getValue("v").equals("paving_stones") ||
             atts.getValue("k").equals("surface") &&  atts.getValue("v").equals("cobblestone") || atts.getValue("k").equals("surface") &&  atts.getValue("v").equals("paved"))
                isGreySurface = true;
            



        }

    }
}



