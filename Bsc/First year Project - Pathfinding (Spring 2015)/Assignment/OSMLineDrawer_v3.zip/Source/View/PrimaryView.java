package source.View;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.BoundingBox;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.transform.Affine;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.controlsfx.control.action.Action;
import org.controlsfx.dialog.Dialog;
import org.controlsfx.dialog.Dialogs;
import source.Model.Coordinate;
import source.Model.Way;

import java.io.File;
import java.util.ArrayList;

import static java.lang.Math.max;

/**
 * Created by Dennis Thinh Tan Nguyen 04-02-2015.
 */
public class PrimaryView extends Application{
    //View inits
    private static boolean launched =false;
    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("PrimaryView.fxml"));
        primaryStage.setResizable(true);
        primaryStage.setTitle("Line drawer X PRO");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    public static void launchApp(String[]arg) {
        if (!launched) {
            launch(arg);
            launched = true;
        }

        else System.out.println("Already running");
    }

    //Fields
    private GraphicsContext gc;
    private Canvas canvas;
    private double xScale,yScale;
    
    private double xTranslate,yTranslate;
    
	private double minLon,maxLat;

    private BoundingBox boundingBox;

	Affine affine = new Affine();
	private static boolean isToggleColour;
    private Color roadStroke;
    private Color buildingFill;

	boolean isBuilding, isWaterWay, isCoastLine, isMainRoad, isMinorRoad, isEveryThingElse;


	//Methods

    public PrimaryView()
    {

    }

    /**
     * Draws image with lines.
     * The coordinates are retrieved from LineObjects
     *
     * index 0 = MainRoads
     * index 1 = MinorRoads
     * index 2 = buildings
     * index 3 = waterWays
     * index 4 = coastlines
     * index 5 = other
     * index 6 = greenArea 
     * index 7 = GreySurface //Stone or asphalt
     *
     */
    public void draw(ArrayList<ArrayList> lines) 
    {
        clearCanvas();
	    gc.setLineCap(StrokeLineCap.BUTT);    //Uses butt cap to stroke lines

        int n = 0;
        for(ArrayList type : lines) {
            if (!type.isEmpty()) {
                drawLines(type, n);
            }
            n++;
        }
    }
    

	/**
	 * This method will draw every lines in an Arraylist consisting of way-objects
	 * @param lines
	 */
	private void drawLines(ArrayList<Way>lines, int type)
	{
		for (Way road : lines)
		{
			ArrayList<Coordinate> coords = road.getWay(); //Retrieving coords

			gc.beginPath();
				for (Coordinate coord : coords)
				{
					gc.lineTo(coord.getX(), coord.getY());
				}

                //Switch between line type
                switch (type) {
                    case 0:
                        drawMainRoad();
                        break;
                    case 1:
                        drawMinorRoad();
                        break;
                    case 2:
                        drawBuilding();
                        break;
                    case 3:
                        drawWaterway();
                        break;
                    case 4:
                        drawCoastLine();
                        break;
                    case 5 :
                        drawGreenArea();
                        break;
                    case 6 : 
                        drawGreySurface();
                }

     			gc.closePath();

		}
	}

	/**
	 * Draws the roads
	 */
	private void drawMainRoad()
	{
		if (isToggleColour) gc.setStroke(roadStroke);
		else gc.setStroke(Color.BLACK);
		gc.setLineWidth(0.00004);
		gc.stroke();

	}

	private void drawMinorRoad()
	{
		gc.setStroke(Color.BLACK);
		gc.setLineWidth(0.00002);
		gc.stroke();
	}


	/**
	 * Draws the buildings
	 */
	private void drawBuilding()
	{
		if (isToggleColour) gc.setFill(buildingFill);
		else gc.setFill(Color.GREY);
		gc.setStroke(Color.BLACK);
		gc.fill();
		gc.stroke();
	}

    /**
     * Draws and fills water related elements 
     */
	private void drawWaterway(){
		if (isToggleColour) gc.setFill(Color.LIGHTBLUE);
		else gc.setFill(Color.LIGHTBLUE);
		gc.setStroke(Color.BLACK);
		gc.fill();
		gc.stroke();
	}

    /**
     * Draws coast line 
     */
	private void drawCoastLine(){
		gc.setFill(Color.BLACK);
		gc.fill();
		gc.stroke();
	}


    /**
     * Draws everything related to green elements. Eg: Forrests 
     */
    private void drawGreenArea(){
        if (isToggleColour) gc.setFill(Color.FORESTGREEN);
        else gc.setFill(Color.LIGHTGREEN);
        gc.setStroke(Color.BLACK);
        gc.fill();
        gc.stroke();
        
    }

    /**
     * Draws everything related to grey elements. Eg: Asphalt or cobblestone 
     */
    public void drawGreySurface()
    {
        gc.setStroke(Color.LIGHTGRAY);
        gc.fill();
        gc.stroke();
    }


    /**
     * Change color of fill and stroke
     * @param fill
     * @param stroke
     * @param lines
     */
    public void ChangeColor(Color fill, Color stroke, ArrayList<ArrayList> lines)
    {
        gc.setFill(fill);
        roadStroke = stroke;
        buildingFill = fill;
        draw(lines);
    }


    /**
     * Toggles the colour on or off 
     */
	public void toggleColor(ArrayList<ArrayList> lines)
	{
		isToggleColour = !isToggleColour;
        draw(lines);
	}


	/**
     * Clears the canvas
     */
    public void clearCanvas()
    {
        gc.clearRect(0,0,canvas.getWidth(),canvas.getHeight());
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());

    }


    public void moveCanvas( double xTranslate, double yTranslate, ArrayList<ArrayList> lines)
    {
        /*
        affine.appendTranslation(xTranslate,yTranslate);
        clearCanvas();
        draw(lines); //Dynamic change
        */
    }


    /**
     * Zoom in by increasing scale
     * @param lines
     */
    public void zoom(double factor, ArrayList<ArrayList> lines)
    {
        dialogMessages("info", "Zooming is currently not supported");
	   /*
	     double xfactor = factor;
	    double yfactor = factor;
	    xScale *= xfactor;
	    yScale *= yfactor;
	    gc.scale(xScale,yScale);
	    draw(lines); //Dynamic change
	    */
        
    }



    /**
     * Universal method to display a dialog box with a message
     * It can either be an info type or error type. We are using controlFX java libraries to show
     * the dialog boxes
     * credits: http://fxexperience.com/controlsfx/
     *
     * @param type ("error" // "info" // "confirmation")
     * @param m message to display.
     */
    public boolean dialogMessages(String type, String m)
    {
        switch (type) {
            case "error":  Dialogs.create()
                    .owner(new Stage())
                    .title("Error Message")
                    .message(m)
                    .showError();
                break;
            case "info": Dialogs.create()
                    .owner(new Stage())
                    .title("Information")
                    .message(m)
                    .showInformation();
                break;
            case "confirmation":
                Action response = Dialogs.create().create()
                        .owner(new Stage())
                        .title("Confirmation")
                        .message(m)
                        .actions(Dialog.ACTION_YES,Dialog.ACTION_NO)
                        .showConfirm();

                if (response == Dialog.ACTION_YES)
                {
                    // ... user chose YES
                    return true;
                } else {
                    // ... user chose NO
                    return false;
                }
        }
        return false;
    }

    /**
     * Method to locate an input file. A fileChooser dialog box will be shown
     * to the user, so he can locate a specific input file
     * @param lastUsedFile last used file location
     */
    public File locateFile(File lastUsedFile)
    {
        FileChooser fileChooser = new FileChooser();

        //Setting extension filters.
       // FileChooser.ExtensionFilter filter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
       // fileChooser.getExtensionFilters().add(filter);

        //Open directory from existing directory
        if(lastUsedFile != null){
            File existDirectory = lastUsedFile.getParentFile();
            fileChooser.setInitialDirectory(existDirectory);
        }

        //Setting extension filters.
        String[] ext = new String[]{"*.txt","*.osm","*.zip"};
        FileChooser.ExtensionFilter filter = new FileChooser.ExtensionFilter("Txt,zip,osm files", ext);
        fileChooser.getExtensionFilters().add(filter);

        //Display dialog
        fileChooser.setTitle("Select map file");
        File file = fileChooser.showOpenDialog(new Stage());

        if (file != null && file.getPath().endsWith(".txt"))
        {
           dialogMessages("info","txt files are not supported at the moment");
           return null;
        }
        else 
        return file;

    }

    /**
     * Resets the transform variables of the map 
     */
    public void resetTransform()
    {

	    xScale = canvas.getWidth()*0.45 / boundingBox.getWidth();
	    yScale = canvas.getHeight() / boundingBox.getWidth();

	    System.out.println(xScale);
	    System.out.println(yScale);

	    affine = new Affine();
	    affine.appendScale(xScale*2, -yScale*2);
	    affine.appendTranslation(-minLon, -maxLat);
        gc.setTransform(affine);


    }

    /**
     * retrieve and set the Graphics context which is parsed
     * by the controller.
     * @param gcArg - Graphics Context
     */
    public void setGC(GraphicsContext gcArg)
    {
        gc = gcArg;
    }

    /**
     * Sets the canvas
     * @param canvas
     */
    public void setCanvas(Canvas canvas){ this.canvas = canvas; }

    /**
     * sets the minimum longitude and maximum latitude.
     * This is used to place the map correctly on the canvas  
     * @param lon
     * @param lat
     */
    public void setLonLat(double lon, double lat)
    {
	    minLon = lon;
	    maxLat = lat;
    }

    /**
     * Sets the bounding box 
     * @param boundingBox
     */
    public void setBBox(BoundingBox boundingBox){
        this.boundingBox = boundingBox;
    }

}

