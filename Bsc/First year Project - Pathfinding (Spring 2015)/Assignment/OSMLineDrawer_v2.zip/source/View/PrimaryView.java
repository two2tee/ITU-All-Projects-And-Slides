package source.View;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.BoundingBox;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.controlsfx.control.action.Action;
import org.controlsfx.dialog.Dialog;
import org.controlsfx.dialog.Dialogs;
import source.Model.Coordinate;
import source.Model.Way;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by Dennis Thinh Tan Nguyen 04-02-2015.
 */
public class PrimaryView extends Application{
    //View inits
    private static boolean launched =false;
    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("PrimaryView.fxml"));
        primaryStage.setResizable(true);
        primaryStage.setTitle("Line drawer X PRO");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    public static void launchApp(String[]arg) {
        if (!launched) {
            launch(arg);
            launched = true;
        }

        else System.out.println("Already running");
    }

    //Fields
    private GraphicsContext gc;
    private Canvas canvas;
    private double xScale,yScale;
    private double xTranslate,yTranslate;
    private BoundingBox boundingBox;

    private static boolean isToggleColour;
    private Color roadStroke;
    private Color roadFill;

    //Methods

    public PrimaryView()
    {

    }

    /**
     * Draws image with lines.
     * The coordinates are retrieved from LineObjects
     * @param buildings
     * @param roads
     */
    public void draw(ArrayList<Way> buildings, ArrayList<Way> roads) {
        clearCanvas();
        gc.setLineCap(StrokeLineCap.BUTT);    //Uses butt cap to stroke lines


        //Draw thick line as stroke
        gc.setLineWidth(2);
        if (isToggleColour) gc.setStroke(roadStroke);
        else gc.setStroke(Color.BLACK);

        //Drawing roads
        for (int i = 0; i < 2; i++) //used to draw second overlapping line // THIS IS PROB HACKS
        {
            for (Way road : roads) {
                ArrayList<Coordinate> coords = road.getWay();

                gc.beginPath();
                for (Coordinate coord : coords) {
                    gc.lineTo(coord.getX(), coord.getY());
                }
                gc.stroke();
                gc.closePath();
            }

            //Draw a thin overlapping  line as fill.
            gc.setLineWidth(1);
            if (isToggleColour) gc.setStroke(roadFill);
            else gc.setStroke(Color.WHITE);
        }


        // DRAWING BUILDINGS
        //Draw thick black line as stroke
        gc.setLineWidth(1);
        gc.setStroke(Color.RED);
        //Drawing Buildings
        for (Way road : buildings) {
            ArrayList<Coordinate> coords = road.getWay();

            gc.beginPath();
            for (Coordinate coord : coords) {
                gc.lineTo(coord.getX(), coord.getY());
            }
            gc.stroke();
            gc.closePath();
        }
    }

    /**
     * Change color of fill and stroke
     * @param fill
     * @param stroke
     * @param buildings
     * @param roads
     */
    public void ChangeColor(Color fill, Color stroke,ArrayList<Way> buildings, ArrayList<Way> roads)
    {
        gc.setFill(fill);
        roadStroke = stroke;
        roadFill = fill;
        draw(buildings,roads);
    }

    /**
     * Clears the canvas
     */
    public void clearCanvas()
    {
        gc.setTransform(1, 0, 0, 1, 0, 0);
        gc.clearRect(0,0,canvas.getWidth(),canvas.getHeight());
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        gc.setTransform(xScale, 0, 0, yScale, xTranslate, yTranslate);

    }


    public void moveCanvas( double xTranslate, double yTranslate,ArrayList<Way> buildings, ArrayList<Way> roads)
    {
        this.xTranslate = xTranslate;
        this.yTranslate = yTranslate;
        clearCanvas();
        gc.setTransform(xScale,0,0,yScale,xTranslate,yTranslate);
        draw(buildings,roads); //Dynamic change

    }


    /**
     * Zoom in by increasing scale
     * @param roads
     * @param buildings
     */
    public void zoomIn(ArrayList<Way> buildings, ArrayList<Way> roads)
    {
            double zoomScale = 1;
            xScale += 1;
            yScale += 1;
            gc.scale(zoomScale, zoomScale);
            draw(buildings,roads); //Dynamic change
    }

    /**
     * Zoom out by decreasing scale
     * @param buildings
     * @param roads
     */
    public void zoomOut(ArrayList<Way> buildings, ArrayList<Way> roads)
    {
            double zoomScale = 0;
            xScale -= 1;
            yScale -= 1;

            gc.scale(zoomScale, zoomScale);
            draw(buildings,roads); //Dynamic change
    }



    public void toggleColor()
    {
        isToggleColour = !isToggleColour;
    }


    /**
     * Universal method to display a dialog box with a message
     * It can either be an info type or error type. We are using controlFX java libraries to show
     * the dialog boxes
     * credits: http://fxexperience.com/controlsfx/
     *
     * @param type ("error" // "info" // "confirmation")
     * @param m message to display.
     */
    public boolean DialogMessages(String type, String m)
    {
        switch (type) {
            case "error":  Dialogs.create()
                    .owner(new Stage())
                    .title("Error Message")
                    .message(m)
                    .showError();
                break;
            case "info": Dialogs.create()
                    .owner(new Stage())
                    .title("Information")
                    .message(m)
                    .showInformation();
                break;
            case "confirmation":
                Action response = Dialogs.create().create()
                        .owner(new Stage())
                        .title("Confirmation")
                        .message(m)
                        .actions(Dialog.ACTION_YES,Dialog.ACTION_NO)
                        .showConfirm();

                if (response == Dialog.ACTION_YES)
                {
                    // ... user chose YES
                    return true;
                } else {
                    // ... user chose NO
                    return false;
                }
        }
        return false;
    }

    /**
     * Method to locate an input file. A fileChooser dialog box will be shown
     * to the user, so he can locate a specific input file
     * @param lastUsedFile last used file location
     */
    public File locateFile(File lastUsedFile)
    {
        FileChooser fileChooser = new FileChooser();

        //Setting extension filters.
       // FileChooser.ExtensionFilter filter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
       // fileChooser.getExtensionFilters().add(filter);

        //Open directory from existing directory
        if(lastUsedFile != null){
            File existDirectory = lastUsedFile.getParentFile();
            fileChooser.setInitialDirectory(existDirectory);
        }

        //Setting extension filters.
        String[] ext = new String[]{"*.txt","*.osm","*.zip"};
        FileChooser.ExtensionFilter filter = new FileChooser.ExtensionFilter("Txt,zip,osm files", ext);
        fileChooser.getExtensionFilters().add(filter);

        //Display dialog
        fileChooser.setTitle("Select map file");
        File file = fileChooser.showOpenDialog(new Stage());

        //if map selected reset scale;
        if (file != null)
        {
            xScale = 1;
            yScale = 1;
        }

        return file;

    }

    public void resetTransform()
    {
        xScale = 1;
        yScale = 1;
        xTranslate = 0;
        yTranslate = 0;
        gc.setTransform(xScale, 0, 0, yScale, 0, 0);
    }

        /**
     * retrieve and set the Graphics context which is parsed
     * by the controller.
     * @param gcArg - Graphics Context
     */
    public void setGC(GraphicsContext gcArg)
    {
        gc = gcArg;
    }
    public void setCanvas(Canvas canvas){ this.canvas = canvas; }

    public void setBBox(BoundingBox boundingBox){
        this.boundingBox = boundingBox;
    }

}

