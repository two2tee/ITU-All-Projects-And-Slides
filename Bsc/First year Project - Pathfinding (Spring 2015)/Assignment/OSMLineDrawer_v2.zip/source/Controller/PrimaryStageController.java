package source.Controller;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.ColorPicker;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.paint.Color;
import source.Model.PrimaryModel;
import source.View.PrimaryView;

import java.io.File;

public class PrimaryStageController {

    //Fields
    @FXML
    private ColorPicker colourPickerFill;

    @FXML
    private ColorPicker colourPickerStroke;

    @FXML
    private Canvas canvas;

    private static double pressedX, pressedY;
    private static double releasedX, releasedY;
    private static double xTranslate, yTranslate;

    private PrimaryModel model;
    private PrimaryView view;


    //Constructor
    public PrimaryStageController(){
        model = new PrimaryModel();
        view = new PrimaryView();
    }

    //initializer
    @FXML
    private void initialize()
    {
        view.setGC(canvas.getGraphicsContext2D());
        view.setCanvas((canvas));
        view.clearCanvas();

        //New color picker
    }

    //Methods
    @FXML
    private void draw()
    {
        view.draw(model.getBuildings(),model.getRoads());
    }

    /**
     * Retrieves the color value of colorPicker and parse it to View;
     */
    @FXML
    private void changeColor()
    {
        view.ChangeColor(colourPickerFill.getValue(), colourPickerStroke.getValue(), model.getBuildings(),model.getRoads());
        draw();
    }


    /**
     * Method used to change status of color being enabled or disabled
     */
    @FXML
    private void toggleColour()
    {
      view.toggleColor();
      draw();
    }

    /**
     * Clears the canvas
     */
    @FXML
    private void clearCanvas(){
        view.clearCanvas();
    }


    /**
     * Zoom function
     * @param event
     */
    @FXML
    private void zoom(ScrollEvent event)
    {
        if(event.getDeltaY()<0)
        {
                view.zoomOut(model.getBuildings(),model.getRoads()); //zoom out
        }
        else
        {
                view.zoomIn(model.getBuildings(),model.getRoads()); //zoom in
        }

    }

    //Panning

    /**
     * Pans the map
     * @param event
     */
    @FXML
    public void pan(MouseEvent event)
    {
        //Stores release location of the mouse
        releasedX = event.getX();
        releasedY = event.getY();

        //mouse distance moved
        double xResult = releasedX-pressedX;
        double yResult = releasedY-pressedY;

        //Add distance moved to translate factor.
        xTranslate+= xResult;
        yTranslate+= yResult;

        //Reassign scale factor and translate before drawing
       view.moveCanvas(xTranslate,yTranslate,model.getBuildings(),model.getRoads());
    }


    /**
     *  Stores the start x,y coordinates of the mouse
     */
    @FXML
    private void getMouseCoords(MouseEvent event)
    {
            pressedX = event.getX();
            pressedY = event.getY();
    }


 //------------------------------------------



    /**
     * Terminates the program
     */
    @FXML
    private void close(){
        System.exit(0);
    }

    /**
     * Load a file with coordinates used to draw the map
     */
    @FXML
    private void loadMap()
    {
        model.clearList();
        File lastUsed =  model.getLastUsed(); //IoHandler.getFile: used to open directory of last opened file
        File locatedFile = view.locateFile(lastUsed);

        if(locatedFile!= null) //in case if user press chancel
        {
            model.readFile(locatedFile);
            view.setBBox(model.getBoundingBox());
            view.resetTransform();
            view.draw(model.getBuildings(),model.getRoads());
        }
    }


    /**
     * Display about message
     */
    @FXML
    private void about()
    {
        view.DialogMessages("info", "Version 0.01 - Angry koala \n Made by Dennis");
    }






}
