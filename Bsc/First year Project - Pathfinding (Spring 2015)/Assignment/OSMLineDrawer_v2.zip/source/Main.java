package source;

import source.View.PrimaryView;

public class Main{

    public static void main(String[] args) {
        PrimaryView.launchApp(args);
    }
}
