package source.Model;

import javafx.geometry.BoundingBox;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.zip.ZipInputStream;

/**
 * Created by Dennis Thinh Tan Nguyen 04-02-2015.
 */
public class IOhandler {


    private File fileUsed;
    private ArrayList<Way> roads = new ArrayList<>();
    private ArrayList<Way> buildings = new ArrayList<>();
    private BoundingBox bbox;
    //File methods

    /**
     * This method will receive a file as parameter and store it in the global field.
     * This method is used when you locate and select a file with address entries
     *
     * @param selected file with address entries
     */
    public void setFile(File selected) {
        fileUsed = null;
        fileUsed = selected;

        if (fileUsed != null)
            System.out.println(fileUsed.getName() + " was selected");

        else
            System.out.println("File could not be selected");
    }

    /**
     * Reads an input file with file extension:
     * .osm - .zip - .txt
     * NOTE: txt. does NOT work right now
     * @param filename
     */
    public void readFile(File filename) {
        try {
            String filePath = filename.getCanonicalPath();
            long time = System.nanoTime();

           // if (filePath.endsWith(".txt")) parseTxT(filename); // NEED REFACT

            if (filePath.endsWith(".osm")) parseOSM(filename);
            else if (filePath.endsWith(".zip")) parseZIP(filename);
            else System.err.println("File not recognized");
            System.out.printf("Model load time: %d ms\n", (System.nanoTime() - time) / 1000000);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns current file
     * @return file
     */
    public File getFile() {
        return fileUsed;
    }

    /**
     * Returns an array list with road coords
     * @return an array list with road coords
     */
    public ArrayList getRoads() {
        return roads;
    }

    /**
     * Returns an array list with building coords
     * @return
     */
    public ArrayList getBuildings() {
        return buildings;
    }

    /**
     * Returns bounding box
     * @return bounding box
     */
    public BoundingBox getBBox(){ return bbox;}

/*
    public ArrayList parseTxT(File filename) {

        ArrayList<Way> lineList = new ArrayList<>();
        long time = System.nanoTime();
        try (BufferedReader input =
                     new BufferedReader(new FileReader(filename))) {

            for (String line = input.readLine(); line != null;
                 line = input.readLine()) {
                String[] words = line.split(" ");
                lineList.add(new Way(
                        Double.parseDouble(words[0]),
                        Double.parseDouble(words[1]),
                        Double.parseDouble(words[2]),
                        Double.parseDouble(words[3])));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.printf("Model load time: %d ms\n",
                (System.nanoTime() - time) / 1000000);
        return lineList;
    }
*/

    /**
     * Parse a zip file containing an OSM file (XML FILE)
     * @param filename zip file
     */
    public void parseZIP(File filename) {
        fileUsed = filename;
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(new FileInputStream(filename)))) {
            zip.getNextEntry();
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(new OSMHandler());
            reader.parse(new InputSource(zip));


        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (org.xml.sax.SAXException e) {
            e.printStackTrace();
        }
    }

    /**
     * Parse an OSM fil
     * @param filename osm file
     */
    public void parseOSM(File filename) {
        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(new OSMHandler());
            System.out.println(filename.toURI().toString());
            reader.parse(filename.toURI().toString());

        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (org.xml.sax.SAXException e) {
            e.printStackTrace();
        }

    }


    /**
     * This nested inner class is responsible for reading and parsing
     * the right information within  a map file (XML file)
     */
    class OSMHandler extends DefaultHandler {
        HashMap<Long, Coordinate> map = new HashMap<>();
        Way way;
        boolean building; //If coords is part of building


        public void endElement(String uri, String localName, String qName) {
            if (qName.equals("way")) {
                if (building)
                {
                    buildings.add(way);
                }
                else
                {
                    roads.add(way);
                }
            }
        }



        public void startElement(String uri, String localName,
                                 String qName, Attributes atts) {
            if (qName.equals("node"))
            {
                nodeToMap(atts);
            }
            else if (qName.equals("nd"))
            {
                setLine(atts);
            }
            else if (qName.equals("way"))
            {
                reset();
            }   //New way and building

            else if (qName.equals("bounds"))
            {
                setBounds(atts);
            }
            else if (qName.equals("tag"))
            {
                setBuilding(atts);
            }
        }



        /**
         * This method will retrieve the latitude and longitude coords
         * of the node, within the XML file/OSM file
         *
         * @param atts  lat and long attribute
         */
        private void nodeToMap(Attributes atts) {
            float lat = Float.parseFloat(atts.getValue("lat"));
            float lon = Float.parseFloat(atts.getValue("lon"));
            long id = Long.parseLong(atts.getValue("id"));

            Coordinate coord = new Coordinate(lon,lat);
            map.put(id, coord);
        }


        /**
         * This method will draw a line?
         *
         * @param atts
         */
        private void setLine(Attributes atts) {
            long id = Long.parseLong(atts.getValue("ref"));
            Coordinate coord = map.get(id);

            if (coord == null) return;

            if (way == null) //new way
            {
               way = new Way(coord.x,coord.y);
            }
            else //already within a way
            {
                way.addMoreCoords(coord.x,coord.y);
            }
        }

        /**
         * This method will way and building everytime the parser encounters a
         * new way tag
         */
        private void reset() {
            way = null;
            building = false;
        }

        /**
         * This method retrieves the bounds info of a map
         *
         * @param atts bound attributes
         */
        private void setBounds(Attributes atts) {

            double minlat =
                    Double.parseDouble(atts.getValue("minlat"));
            double minlon =
                    Double.parseDouble(atts.getValue("minlon"));
            double maxlat =
                    Double.parseDouble(atts.getValue("maxlat"));
            double maxlon =
                    Double.parseDouble(atts.getValue("maxlon"));
            bbox = new BoundingBox(minlon, minlat, maxlon - minlon, maxlat - minlat);


        }

        /**
         * This method will set building to true every time
         * the parser encounters a k take equals to building.
         * This is used to separate roads and buildings
         *
         * @param atts
         */
        private void setBuilding(Attributes atts) {
            if (atts.getValue("k").equals("building"))
                building = true;
        }

    }
}



