package source.Model;

import javafx.geometry.BoundingBox;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by Dennis Thinh Tan Nguyen 04-02-2015.
 */
public class PrimaryModel {

    IOhandler iOhandler;
    ArrayList<Way> buildings;
    ArrayList<Way> roads;

    /**
     * Constructor
     */
    public PrimaryModel(){
        iOhandler = new IOhandler();
        buildings = new ArrayList<>();
        roads = new ArrayList<>();
    }

    /**
     * Reads and parses the loaded file
     * @return address file
     */
    public void readFile(File filename)
    {
        iOhandler.setFile(filename); //setting file
        iOhandler.readFile(filename);

        buildings = iOhandler.getBuildings();
        roads = iOhandler.getRoads();



    }


    /**
     * Retrieve last used file. It's location will be used when you want
     * to load another map
     * @return last used file
     */
    public File getLastUsed() {
        return iOhandler.getFile();
    }

    /**
     * Retrieves an arraylist of road coords
     * @return Arraylist<Way> --> road coords
     */
    public ArrayList<Way> getRoads()        {    return roads;    }

    /**
     * Retrieves an arraylist of building coords
     * @return Arraylist<Way> --> building coords
     */
    public ArrayList<Way> getBuildings()    {    return buildings;}

    /**
     * Returns the boundingBox
     * @return boundingBox
     */
    public BoundingBox getBoundingBox()     {    return iOhandler.getBBox(); }

    /**
     * Clears both arrayList (Buildings and roads)
     */
    public void clearList()
    {
        buildings.clear();
        roads.clear();
    }
}


