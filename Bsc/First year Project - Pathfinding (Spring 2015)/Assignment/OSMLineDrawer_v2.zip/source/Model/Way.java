package source.Model;

import java.util.ArrayList;

/**
 * Created by Dennis Thinh Tan Nguyen 07-02-2015.
 */
public class Way {
   ArrayList<Coordinate> coordinates;

    public Way(double x, double y)
    {
        coordinates = new ArrayList<Coordinate>();
        coordinates.add(new Coordinate(x,y));
    }
    
    public void addMoreCoords(double x, double y)
    {
        coordinates.add(new Coordinate(x,y)); 
    }
    
    public ArrayList<Coordinate> getWay()
    {
        return coordinates;
    }

    
    

}
