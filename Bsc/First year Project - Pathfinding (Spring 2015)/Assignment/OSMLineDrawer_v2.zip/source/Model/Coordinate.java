package source.Model;

/**
 * Created by Dennis Thinh Tan Nguyen 17-02-2015.
 */
public class Coordinate {
        double x,y;
        public Coordinate(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        //Getter
        public double getX() {
            return x;
        }
        public double getY(){
            return y;
        }

}
