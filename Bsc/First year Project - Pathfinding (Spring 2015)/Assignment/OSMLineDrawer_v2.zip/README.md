Linedrawer X PRO-Cheap
==========


---- HOW TO USE -----
- HOW TO LOAD A MAP -
 - PRESS THE LOAD BUTTON at the lower right corner.
 - Locate a map file
   - Zip file or OSM file (txt file does not work for now)
 - Press load

- HOW TO ZOOM -
 - Scroll forward with the mouse wheel to zoom in
 - Scroll backwards with the mouse wheel to zoom out.


- HOW TO PAN -
 - Drag the map with the mouse to pan the canvas



----- FEEDBACK -----
Der er en ting som jeg gerne vil have feedback til

    - 1: Programmet loader xml-filen helt fint, men problemet er at jeg bare får tegnet en klat
    (Abstrakt kunst) og ikke et kort.

    Kan dette skyldes at man bør formatere koordinaterne når man får dem læst ned?


    - Kort sagt opretter jeg "way" objekter, som indeholder et arraylist med Coordinate objekter.
     Disse Coordinate objekter indeholder blot et koordinatsæt (lat og lon) og tilsammen udgør alle coordinate objekter i
     "way" en path.


     Jeg tegner så mine ways ved at:

     //DRAWING LINE
     LOKATION :
        Klasse: PrimaryView
        Metode: draw();
        Linje : 83-92
                                NOTE: gc = GraphicalContext

     for (Way road : roads)
            {
                ArrayList<Coordinate> coords = road.getWay(); // Retrieve coordlist

                gc.beginPath();
                for (Coordinate coord : coords) {
                    gc.lineTo(coord.getX(), coord.getY());
                }
                gc.stroke();
                gc.closePath();
            }



   Her er metoden som jeg bruger til at oprette mine way objekter (Findes inde i innerclassen OSMHandler)

   LOKATION :
        Klasse: IOhandler
        Metode: setLine(...);
        Linje : 235-249

     private void setLine(Attributes atts)
     {
            long id = Long.parseLong(atts.getValue("ref"));
            Coordinate coord = map.get(id);

            if (coord == null) return;

            if (way == null) //new way
            {
               way = new Way(coord.x,coord.y);
            }
            else //already within a way
            {
                way.addMoreCoords(coord.x,coord.y);
            }
        }





