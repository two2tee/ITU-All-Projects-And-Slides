AdresseParser
=============


-----//FEEDBACK REQUEST//-----------------------------------------------------------------------------------------------
I would like to have some feedback on the following parts of the program

 - Issues with regular expressions
    My city column on the tableView doesn't get the right information...
    - There is something wrong mit my regular expressions, but i can't seem to figure out what is
        wrong. Please help me thank you

        Location
        - Class --> Address
        - Line  --> 92-97


        - Short description of the above problem -

        I have created local string variables which represents each part of the address, that is used to
         define a regular expression by concatenating them. They can be concatenated in different ways
         which will be used as patterns.

         Note: ("ahfspc" and similir strings)
            patternList.add(address + house + floor +  side + postCode + city + "%" + "ahfspc"); <----

            Defines how the groups should be parsed to the builder (We are using substrings to retrieve the letters one by one)
            Defintion
                a --> address eg: Ruedlangaardsvej
                h --> house   eg: 5
                f --> floor
                s --> side
                p --> postcode
                c --> City

        The problem is the fact that the groups formed by the regular expressions are wrong.. Thus it returns wrong output




////// MANUAL TO ADDRESS PARSER X ///////-------------------------------------------------------------------------------

Thank you for buying ADDRESS PARSER X.
ADDRESS PARSER X allows you to input and validate any address. It can display them on a table,
load an existing address filedatabase or even save your current inputted addresses to a new Address database file.

//-- HOW TO INPUT SINGLE ADDRESS --//
    - Press "Input Address" button in the lower right corner
    - (Alternative way)  Press "Modify" tab on the menu at the top of the window
       - Press "Input Address" tab

    - A new input window should appear
    - Input address part to each corresponding textfield
    - Press "Submit" button in the dialog window
        - A dialog box should now appear and inform whether the submission was successful or not.



//-- HOW TO REMOVE A SINGLE ADDRESS ENTRY FROM TABLE --//
    -Select an address entry my clicking on an address row in the table
    -Press "Modify" Tab tab on the menu at the top of the window
    -Press "Remove Address" Tab
        - The address should now disappear from the table
         NOTE: This won't remove the entry from a loaded file, unless you save and overwrite the file.




//-- HOW TO UNDO LAST ACTION  --//
    -Press "Modify" Tab tab on the menu at the top of the window
    -Press "Undo" Tab
        - The last action made is undone
         NOTE: This won't change a loaded Address Database, unless you save and overwrite the file.




//-- HOW TO SAVE TABLE TO ADDRESS DATABASE FILE  --//
    -Press "File" tab on the menu at the top of the window
    -Press "Save address file"
        - A new Dialog box should now appear
    -Specify the save location and name of file
    -Press "Save" button to save
        - If file with existing name already appears you will be prompted if you want to overwrite the file
        - Press "Cancel" to cancel saving



//-- HOW TO LOAD TABLE TO ADDRESS DATABASE FILE  --//
    - Press "Locate file" button
        -  (Alternative way) Press "File" tab tab on the menu at the top of the window
        -  Press "Load address file"

    - A new Dialog box should now appear
    -Specify the location the Address Database file
    -Press "Load" button
    -Press "Retrieve" button to load the file into the table
        - If unsaved data is in table, user will be prompted if he wants to overwrite the table





 - Test suite provided by Troels doesn't seem to work. I get a nullPointerException on 99% of every
   test in the suite when i run them. I have already copied the Address.Java file into the test project....









------------------------------------------------------------------------------------------------------------------------
copyright(c) & All rights reversed : Dennis Thinh Tan Nguyen

-----//DISCLAIMER//------
IN NO EVENT SHALL CREATOR BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
INCLUDING LOST PROFITS, GLOBAL WARMING, DEAD CATS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
EVEN IF CREATOR HAS BEEN ADVISED OR TUTORED OF THE POSSIBILITY OF SUCH DAMAGE.

CREATOR SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE AND
ACCOMPANYING DOCUMENTATION, IF ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".
CREATOR HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, MODIFICATIONS OR PAY YOUR HOUSE RENT.
THIS SOFTWARE WON'T SAFE THE WORLD FROM DISASTERS, TERRORISM, ALIENS OR MAKE YOU SEXY BUT YOU ARE ALLOWED TO
IMAGINE THAT.


STAY SAFE AND HAPPY




////// ASSIGNMENT DESCRIPTION ///////-----------------------------------------------------------------------------------
This assignment is twofold:

You must write a function for parsing user text input as an address (you decide how user input is provided).
There is no final answer to this part; any solution can always be improved to handle more special cases.
A useful toolset for this task is that of regular expressions.

You must write a simple MVC-based user interface that lets a user input addresses,
and displays the addresses in a way that reflects how the addresses have been parsed.
This does not have to be interactive; it is fine to only allow user input at startup, though interactive is better.
Specifically, you must complete the

public static Address parse(String s) { ...
method of the class Address.java.

You must not change anything else about that class, as your solution to this will be a part of later exercises.

The rest of the program should as a minimum include the following classes:

Model.java: stores the entered addresses
View.java: displays the entered addresses in a window
Controller.java: handles user input
Your hand-in must consist of three files:

a .jar file that can be run, and which also contains the source code. Most IDEs have built in support for this.

Alternatively, you can also create it from the command line using this guide:
  jar cmf MANIFEST.MF MyUserName.jar *.class *.java
  a screenshot of the program window, showing the awesome graphics you have made
  a .txt file with instructions for how to run the program (i.e., are the addresses given in a file, or on
  the command line, or have you actually made a proper gui), and any requests for feedback about your solution.
  It is also fine to write "No feedback needed", if that is the case.

This hand-in is not mandatory, but it will be used as part of the group formation process, and the Address.java file
will be play a part of the exercises in the second week of the course.



