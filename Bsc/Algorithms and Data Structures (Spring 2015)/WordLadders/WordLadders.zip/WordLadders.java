import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.plaf.FileChooserUI;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

/**
 * Created by William on 15/04/15.
 */
public class WordLadders
{
	BreadthFirstDirectedPaths breadthFirstDirectedPaths;
	Digraph digraph;
	SeparateChainingHashST<String, ResizingArrayBag<String>> wordCombination; // 4-5 letter combination mapping
	SeparateChainingHashST<String, Integer> wordsInteger = new SeparateChainingHashST<>(); //Array with 5 letter words
	ArrayList<String> words;
	int vCounter;


	WordLadders()
	{
		wordCombination = new SeparateChainingHashST<>();
		wordsInteger = new SeparateChainingHashST<>(); //Used for integer lookup
		words = new ArrayList<>();
		vCounter = 0;

	}

	private void createFourLetters(String s)
	{

		for (int i = 0; i < s.length(); i++)
		{

			//Delete chars
			StringBuilder sb = new StringBuilder(s).deleteCharAt(i);
			char[] charSequence = sb.toString().toCharArray();

			//Sort String combination
			Arrays.sort(charSequence);
			String sortedWord = new String(charSequence);

			//Add 4 letter as key and 5 letter as value in bag
			if (wordCombination.contains(sortedWord))
			{
				ResizingArrayBag bag = wordCombination.get(sortedWord);
				bag.add(s);
			} else
			{
				wordCombination.put(sortedWord, new ResizingArrayBag<String>());
				wordCombination.get(sortedWord).add(s);
			}

		}
		wordsInteger.put(s, vCounter);
		words.add(s);
		vCounter++;
	}

	public void createDigraph()
	{
		digraph = new Digraph(wordsInteger.size());
		for (String word : wordsInteger.keys())
		{
			//removes first char
			StringBuilder sb = new StringBuilder(word).deleteCharAt(0);
			char[] charSequence = sb.toString().toCharArray();

			//Sort String combination
			Arrays.sort(charSequence);
			String sortedWord = new String(charSequence);

			//Compare word and add edge
			if (wordCombination.contains(sortedWord))
			{
				Iterator bag = wordCombination.get(sortedWord).iterator();

				//Iterate over bag and connect words in bag with compared word
				while (bag.hasNext())
				{
					String bagItem = (String) bag.next();
					int from = wordsInteger.get(word);
					int to = wordsInteger.get(bagItem);

					digraph.addEdge(from, to);
				}
			}
		}

	}

	public void calcShortestPath(String a, String b)
	{
		int from = wordsInteger.get(a);
		int to = wordsInteger.get(b);

		breadthFirstDirectedPaths = new BreadthFirstDirectedPaths(digraph, from);
		if (breadthFirstDirectedPaths.hasPathTo(to))
		{
			StdOut.println("");
			StdOut.println("From: " + a + " To: " + b );
			StdOut.println("Distance calculated: " + breadthFirstDirectedPaths.distTo(to));

			StdOut.println("Shortest path: ");
			for (int i : breadthFirstDirectedPaths.pathTo(to))
			{
				StdOut.println(words.get(i));
			}
		} else StdOut.println("No path was found with the two words");
	}


	public File loadFile(String name)
	{
		JFileChooser fileChooser = new JFileChooser();

		//Define filters
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
				"txt files", "txt");
		fileChooser.setFileFilter(filter);


		//Show dialogbox
		fileChooser.setDialogTitle(name);
		int returnVal = fileChooser.showOpenDialog(new JPanel());
		if (returnVal == JFileChooser.APPROVE_OPTION)
		{
			return fileChooser.getSelectedFile();
		}
		return null;
	}


	public static void main(String[] args)
	{
		WordLadders wordLadders = new WordLadders();

		Scanner s = null;

		try
		{
			s = new Scanner(new BufferedReader(new FileReader("words-5757.txt")));

			while (s.hasNext())
			{
				wordLadders.createFourLetters(s.next());
			}
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (s != null)
			{
				s.close();
			}
		}

		wordLadders.createDigraph();

		funHacks();

		StdOut.println("This application builds a digraph from the file words-5757.txt as described in the task description.");
		StdOut.println("Please type the path of the file which you want to compare with words-5757.txt.");
		StdOut.println("An Example is: words-5757-in.txt if the file is contained within the same directory as " + 
			"Wordladdres.java");
		StdOut.println("Else another example could be: /Users/William/Desktop/words-5757-in.txt");



		try
		{
			s = new Scanner(new BufferedReader(new FileReader(StdIn.readLine())));

			while (s.hasNext())
			{
				wordLadders.calcShortestPath(s.next(), s.next());
			}
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (s != null)
			{
				s.close();
			}
		}
		StdOut.println("");
	}

	private static void funHacks(){
		StdOut.println("");
		StdOut.println(" \t\n" +
					"\n" +
					"             ,----------------,              ,---------,\n" +
					"        ,-----------------------,          ,\"        ,\"|\n" +
					"      ,\"                      ,\"|        ,\"        ,\"  |\n" +
					"     +-----------------------+  |      ,\"        ,\"    |\n" +
					"     |  .-----------------.  |  |     +---------+      |\n" +
					"     |  |                 |  |  |     | -==----'|      |\n" +
					"     |  |  WE LOVE ALGS!  |  |  |     |         |      |\n" +
					"     |  |  Bad command or |  |  |/----|`---=    |      |\n" +
					"     |  |  C:\\>_          |  |  |   ,/|==== ooo |      ;\n" +
					"     |  |                 |  |  |  // |(((( [33]|    ,\"\n" +
					"     |  `-----------------'  | ,\".;'| |((((     |  ,\"\n" +
					"     +-----------------------+  ;;  | |         |,\"\n" +
					"        /_)______________(_/  //'   | +---------+\n" +
					"   ___________________________/___  `,\n" +
					"  /  oooooooooooooooo  .o.  oooo /,   \\,\"-----------\n" +
					" / ==ooooooooooooooo==.o.  ooo= //   ,`\\--{)B     ,\"\n" +
					"/_==__==========__==_ooo__ooo=_/'   /___________,\"\n" +
					"`-----------------------------'\n");

		StdOut.println("");
	}
}

