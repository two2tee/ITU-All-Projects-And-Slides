public class Hammer extends Tool {
    private boolean is_thors_hammer;
    
    public Hammer(int weight, String owner, String desc, boolean is_thors_hammer) {
        super(weight, owner, desc);
        this.is_thors_hammer = is_thors_hammer;
    }
    
    public String toString() {
        String s = super.toString();
        if (is_thors_hammer) {
            return s + " which IS indeed Thor's hammer!!!";
        } else {
            return s + " which is NOT Thor's hammer";
        }
    }
    
    public void display() {
        super.display();
        // weight++;
        System.out.print(" which weighs " + weight + " kg");
        if (is_thors_hammer) {
            System.out.println(" which IS indeed Thor's hammer!!!");
        } else {
            System.out.println(" which is NOT Thor's hammer");
        }
    }
    
    public void hit() {
        if (is_thors_hammer) {
            System.out.println("BAM!");
        } else {
            System.out.println("BAAAAAAMMMMM!!!!!");
        }
    }
}
