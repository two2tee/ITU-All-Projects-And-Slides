public class Tool {
    protected int weight;
    private String owner;
    private String description;
    
    public Tool(int weight, String owner, String desc) {
        super();
        this.weight = weight;
        this.owner = owner;
        description = desc;
    }
    
    public String toString() {
        return owner + "'s tool : " + description;
    }
    
    public void display() {
        System.out.print(owner);
        System.out.print("'s tool : ");
        System.out.print(description);
    }
}
