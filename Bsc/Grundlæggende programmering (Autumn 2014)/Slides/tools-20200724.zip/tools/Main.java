
public class Main {
    public void start() {
        Hammer h;
        h = new Hammer(10, "Obama", "Obama's Tool", false);
        h.display();
        h.hit();
        h = new Hammer(99, "Thor", "Mjolner", true);
        h.display();
        h.hit();
    }
}
