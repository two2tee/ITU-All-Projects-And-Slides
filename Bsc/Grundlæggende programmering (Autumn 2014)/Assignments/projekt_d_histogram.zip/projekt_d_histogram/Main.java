package projekt_d_histogram;

/**
 * @author 
 * Dennis Thinh Tan Nguyen
 * email - dttn@itu.dk
 */
public class Main {

	/**
	 * Main class with main method.
	 * - Creates a new GUI object.
	 */
	public static void main(String[] args) 
        {
            new GUI();
	}
}
