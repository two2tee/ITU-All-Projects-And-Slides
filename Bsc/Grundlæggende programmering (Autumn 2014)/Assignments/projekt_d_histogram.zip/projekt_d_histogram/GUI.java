package projekt_d_histogram;

import java.awt.Dimension;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 * This class represent a GUI where a new graph object will be created and 
 * added to our content pane.
 * @author 
 * Dennis Thinh Tan Nguyen
 * dttn@itu.dk
 */
public class GUI extends JFrame{

    //Constructor
	public GUI()
	{
            makeFrame();
	}
/**
 * ´This method draws the frame
 *  - Size of frame: 400*500
 **/
	private void makeFrame() {
            setTitle("Histogram - Aflevering D");
            setMinimumSize(new Dimension(400,500)); 
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            
            getContentPane().add(new Graph());
            
            setVisible(true);

	}
	
	
	
	
}
