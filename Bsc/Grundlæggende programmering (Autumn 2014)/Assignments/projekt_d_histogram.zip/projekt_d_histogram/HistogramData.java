package projekt_d_histogram;

/**
 * This class creates an object which handles and stores our data in two arrays 
 * values[] - Stores integers
 * elements[] - Stores strings
 *
 * @author 
 * Dennis Thinh Tan Nguyen
 * dttn@itu.dk
 */
public class HistogramData {

//Fields
	private final int[] values;
	private final String[] elements;
	
//Constructor
	
	/**
	 * Constructor for HistogramData
        
         * @param 
         *  IntArray - int[] values
         * @param 
         *  StringArray - String[] elements
	 */
        public HistogramData(int[] values, String[] elements)
        { 
            this.values = values;
            this.elements = elements;
        }
        
   
//Methods
	
	/**
	 * Get a Specific value from the ValueList
         * @param i 
         * integer index i
	 * @return
	 * Returns an integer
	 */
	public int getValue(int i)
	{
		int result = 0;
		try
		{
			result = values[i]; 
		}
		catch(NullPointerException e) //if nullPointerException then printStackTrace 
		{
			e.printStackTrace();
		}
                catch(ArrayIndexOutOfBoundsException e) // If the index is refering to something that is out of bound
                                                        // an ArrayIndexOutOfBoundsException will be thrown and handled in the catch block 
                {
                        e.printStackTrace();
                }
		return result; 
	}
	
	
	/**
	 * Returning the highest value in the value list
	 * @param 
         *  index - Int i 
	 * @return
	 * Returning the highest integer in value list.
	 */
	public int getHighestValue()
	{
		int highestValue = 0;
		
		try
		{
                    for (Integer key : values) 
                        {
                        int value = key;
                        highestValue = Math.max(highestValue, value); //Comparing both values. IF value is greater than highestValue, replace
                                                                      // it with value.
			}
			
		}
		
		catch(NullPointerException e)//if nullPointerException then printStackTrace 
		{
			e.printStackTrace();
		}
                catch(ArrayIndexOutOfBoundsException e) //if ArrayIndexOutOfBounds then printStackTrace 
                {
                        e.printStackTrace();
                }
		
		return highestValue;		
	}
	
	
	
	/**
	 * Returning label element from the list of labels
	 * @param 
         * index - Int i 
	 * @return
	 * Returning a string from the element list.
	 */
	public String getElement(int i)
	{
		String element = null;
		try
		{
			element = elements[i]; 
		}
		catch(NullPointerException e) //if nullPointerException then printStackTrace 
		{
			e.printStackTrace();
		}
                                
                catch(ArrayIndexOutOfBoundsException e) //if ArrayIndexOutOfBounds then printStackTrace 
                {
                        e.printStackTrace();
                }
                
		return element;		
	}
	
	/**
	 * This method returns the length of ValueList
	 * @return
	 * Returns an integer
	 */
	public int getValueListLenght()
	{
            int ValueLenght = 0;
                try
                {
                    ValueLenght = values.length;
                }
                catch(NullPointerException e)
                {
                    e.printStackTrace();
                }
                
            return ValueLenght;
	
        }
	
	/**
	 * This method returns the length of ElementList
	 * @return
	 * Returns a string
	 */
	public int getLabelListLenght()
	{
            int elementLenght = 0;
              try
                {
		elementLenght = elements.length;
                }
              catch(NullPointerException e)
              {
                  e.printStackTrace();
              }
            return elementLenght;
	}
}
