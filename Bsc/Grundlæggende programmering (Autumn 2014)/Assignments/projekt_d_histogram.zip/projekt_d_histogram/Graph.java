package projekt_d_histogram;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JComponent;

/**
 * This class creates an object, which draws histogram our histogram.
 * The object will be implemented and shown in our GUI object.
 * @author 
 * 
 * Dennis thinh Tan Nguyen
 * dttn@itu.dk
 */
public class Graph extends JComponent {

	//Fields
	private HistogramData data;
        private float ScalingPercentage;
        
        private final int xAxisStart = 100;
        private final int xAxisEnd = 300;
        private final int yAxisStart = 400;
        private final int yAxisEnd = 200;
        private final int xAxisLength = xAxisEnd - xAxisStart;
        private final int yAxisLength = yAxisStart - yAxisEnd;
        

	/**
         * Constructor uses two arrays as parameter and creates 
         * a new HistogramData Object with two new predefined arrays.
         * We use
         *  - an int array
         *  - a string array
         */
	public Graph()
        {
            //
            try
            {
                data = new HistogramData(new int[]{150, 200 ,130,100}, new String[] {"UK","DK","BR","FR"});
            }
            catch(ArrayStoreException e) //If a wrong type of object as been used, an ArrayStoreException is thrown
            {
               e.printStackTrace();
            }
            catch(NegativeArraySizeException e) //If a Array is created with a negative size
            {
                e.printStackTrace();
            }
                
        }
	
	/**
	 * This method will run every draw methods in this class
	 */
        @Override
	public void paint(Graphics g)
	{
		drawAxis(g);
		drawPillarsAndLabels(g);					
	}

	/**
	 * Draws a horizontal line representing the x-axis
	 */
	private void drawAxis(Graphics g) {
		//Draws a Vertical line representing the x-axis
                g.setColor(Color.BLACK);
		g.drawLine(xAxisStart, yAxisStart, xAxisEnd, yAxisStart);
		
                
                //Draws a Vertical line representing the y-axis
                g.setColor(Color.BLACK);
		g.drawLine(xAxisStart, yAxisStart,xAxisStart, yAxisEnd); // Setting the height of y
		
	}


	
	/**
	 * This method draws every Data-pillars and labels in our histogram 
	 */
	private void  drawPillarsAndLabels(Graphics g)
	{
		//local fiels
                double scaleFactor = ((double)yAxisLength)/((double)data.getHighestValue());
                double columnWidth = (((double)xAxisLength)/((double)data.getValueListLenght()))*0.5;
                double columnGap = (((double)xAxisLength)/((double)data.getValueListLenght()))*0.5;
                int xStart = xAxisStart+(int)columnGap;
                        
		
	 	for(int i = 0; i < data.getValueListLenght(); i++) 
	 	{
                    //Calculating given value compared to maxValue - Used to 
                    //calculate pillar height
                     int scalingHeight = ((int)(data.getValue(i)*scaleFactor));
                     int yStart = yAxisLength-scalingHeight+yAxisEnd;
                     
                    
                    //Drawing pillar
                    g.fillRect(xStart, yStart,((int)columnWidth), scalingHeight); //Getting the negativ value so we can get a positiv graph + 100 for buffer in height
                                        
                    //Drawing labels x axis
                    g.drawString(data.getElement(i), xStart, yAxisStart + 15);

                    //drawing label-value on pillars
                    g.drawString(Integer.toString(data.getValue(i)), xStart, yStart - 5); // Converting value int to string - Use as label
                    g.drawString(("0"), 90, 400); //adding 0 to y axis label 	
                    
                    //Adding extra titel-label
                    g.drawString("Just another Histogram", xAxisStart+25, (yAxisStart - 300)); //adding a titel label	
  
                    //Increment for x coordinate
                    xStart += columnWidth+columnGap;
                }
                      

                /**
                 * Isn't there a better way to add those labels on our y-axis in case the numbers get bigger?
                 * for example if we use numbers such as 1000000000.
                 * The length of that number will end up crossing the y-axis line.
                 * I've tried with some if else statements where i increase their x-placement, but that wasn't optimal.
                 */               
                //drawing crossing line and labels on y-values  
                for(int n = 1 ; n <= 10; n++) 
                      {
                        g.drawLine(xAxisStart - 10, (yAxisStart - (yAxisLength/10)*n), xAxisStart,(400 - (yAxisLength/10)*n));
                        g.drawString(Integer.toString((int)((double)data.getHighestValue()/10.0)*n), 65,  yAxisStart-((yAxisLength/10*n)));
                      }
             }	
}






