/**
 * Timer class
 * Created by Dennis Thinh Tan Nguyen on 18/11/14.
 * Email: dttn@itu.dk
 */
class Timer {

    private final ThreadLocal<Long> start = new ThreadLocal<Long>();

    public Timer() {
        start.set(System.currentTimeMillis());
    }

    public double calcTime()
    {
        return (System.currentTimeMillis()- start.get())/1000.0;
    }

    public void printTime(){
        System.out.println("Sorted in: " + calcTime() + " seconds");
    }


}
