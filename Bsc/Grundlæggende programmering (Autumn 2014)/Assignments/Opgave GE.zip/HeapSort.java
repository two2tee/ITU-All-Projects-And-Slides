/**
 * Heap sort class
 * Created by DennisThinhTan on 18-Nov-14.
 * Email: dttn@itu.dk
 */
class HeapSort extends Sort {

    private static void heapify(int[] arr, int i, int k)
    {
        int j = 2 * i + 1;
        if(j <= k)
        {
            if(j+1 <= k && arr[j] < arr[j+1])
            {j++;}
                if(arr[i]<arr[j])
                {
                    swap(arr,i,j);
                    heapify(arr,j,k);
                }

        }
    }

    public static void sort(int[]arr,int n)
    {
        for(int m = n/2 ; m >= 0 ; m--){
            heapify(arr, m, n-1);
        }
        for(int m = n-1 ; m >= 1 ; m--){
            swap(arr,0,m);
            heapify(arr,0,m-1);
        }
    }
}
