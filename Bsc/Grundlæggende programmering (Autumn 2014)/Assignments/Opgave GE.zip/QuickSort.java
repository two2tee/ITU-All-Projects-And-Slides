/**
 * Quick sort class
 * Created by DennisThinhTan on 18-Nov-14.
 * Email: dttn@itu.dk
 */
class QuickSort extends Sort {


    public QuickSort() {}

    public static void sort(int[]arr,int n){
        qSort(arr, 0 , (n-1));
    }


    private static void qSort(int[] arr, int a, int b)
    {
        if (a < b)
        {
            int i = a, j= b;
            int x = arr[(i+j)/2];
            do{
                while (arr[i] < x) i++;
                while (arr[j] > x) j--;
                if(i <= j)
                {
                    swap(arr,i,j);
                    i++; j--;
                }
            } while (i <= j);
            qSort(arr, a, j);
            qSort(arr, i, b);
        }
    }
}
