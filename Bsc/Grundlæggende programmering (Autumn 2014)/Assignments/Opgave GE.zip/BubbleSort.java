/**
 * Bubble sort class
 * Created by new on 19-11-2014.
 * Email: dttn@itu.dk
 *
 * Best time
 * The best case is when the collection is already ordered. The process will only have to iterate over the collection
 * a single time.
 *
 * Worst time
 * The worst case is when the collection is reverse-ordered.
 * The process will have to iterate and swap every element in the collection which can be explained by the following
 * equation:
 * (n-1)+(n-2)+(n-3)+...+1 = n(n-1)/2
 *
 * Taking this into consideration, bubblesort can still be used with small collection. However, this method should be
 * avoided when the collection is very large because the time consumption for sorting n elements using bubble sort
 * asymptotically proportional to n^2.
 */
class BubbleSort extends Sort{


    /**
     * This method compares the element j with j+1. If j is smaller than j+1, they will swap place.
     * This sorting process continues until the array is ascended sorted.
     *
     * @param arr - arr uses an array with integers as parameter. The array is being created in the DataArray Class
     * @param arrLength - is the length of arr.
     */
    public static void sort( int [ ] arr, int arrLength )
    {
        int j;                  //
        boolean swapped = true;   // set swapped to true to start


        while ( swapped )
        {
            swapped= false;    //set swapped to false awaiting a possible swap
            for( j=0;  j < (arrLength - 1);  j++ )
            {
                if ( arr[ j ] > arr[j+1] )   // Set < for descending sort and > for ascending sort
                {
                    swap(arr,j,j+1);  //swap elements j and j+1
                    swapped = true;  //set swap to true so the process can be run again
                }
            }
        }
    }
}
