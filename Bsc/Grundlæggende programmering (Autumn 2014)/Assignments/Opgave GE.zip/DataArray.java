import java.util.Random;

/**
 * DataArray creates an object with an array consisting of integers as elements.
 * The object will also call a corresponding sort method , which will sort
 * the array in an acceding order,
 *
 * The implemented sorting methods are:
 *
 * Selecting Sort
 * Quick Sort
 * Heap Sort
 * Bubble Sort
 *
 * Created by Dennis Thinh Tan on 18-Nov-14.
 */
class DataArray {

    //Fields
    private int[] array;


    /**
     * Constructor -
     * This constructor will create an array with n numbers of elements
     * and initiate a corresponding sort method.
     */
    public DataArray(int n, int i) {

        //Creates an array with n numbers of elements
        fillArray(n);

        //Calling sort methods
        chooseSortType(i);

    }

    /**
     * The method will also select a sorting method corresponding to a given integer.
     *
     * @param i - points at a specific sort method.
     */
    private void chooseSortType(int i) {
        switch (i) {
            case 1:
                selSort();
                break;

            case 2:
                quickSort();
                break;

            case 3:
                heapSort();
                break;

            case 4:
                bubbleSort();
                break;

            default: {
                System.out.println("Please insert a valid index number \n" + //In case of invalid parameter
                        "1:Selecting Sort \n" +
                        "2:Quick Sort \n" +
                        "3:Heap Sort \n" +
                        "4: Bubble Sort");

                System.exit(0);
            }
        }
    }


    /**
     * This method will create an array with a specific number of elements.
     * @param n -  element quantity
     */
    private void fillArray(int n)
    {
        Random random = new Random();

        array = new int[n];
        for(int i=0; i< n; i++)
        {
            array[i] = random.nextInt(10001); // Insert a random integer fro, 0 - 10000
        }
    }


//  /**
//     * For testing purpose - This method will print every elements in an array out to t
//     * terminal
//     * @param s - Name of sorting method
//    */
//    private void printList(String s){
//        System.out.println("------------------------"+s+"--------------------------");
//        for (int anArray : array) {
//            System.out.print(anArray + "\n");
//        }
//    }
// --Commented out by Inspection STOP (19-11-2014 20:56)





    //Sort methods//


    /**
     * Selecting sort - Initiate selecting sort.
     */
    private void selSort()
    {
        SelectionSort.sort(array, array.length);
    }

    /**
     * Heap sort Bubble sort - Initiate quick sort.
     */
    private void quickSort()
    {
        QuickSort.sort(array, array.length);
    }

    /**
     * Heap sort Bubble sort - Initiate heap sort.
     */
    private void heapSort()
    {
        HeapSort.sort(array, array.length);
    }

    /**
     * Bubble sort - Initiate bubble sort.
     */
    private void bubbleSort() {
        BubbleSort.sort(array, array.length);
    }



}
