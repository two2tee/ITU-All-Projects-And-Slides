import java.util.HashMap;

/**
 * This is the main class.
 * "Change valid index number in sortType if you want to use another sorting method
 1: Selecting Sort
 2: Quick Sort
 3: Heap Sort
 4: Bubble Sort
 */
class Main {

    public static void main(String[] args) {
        //Local fields
        HashMap<Integer, String> printSortType = new HashMap<Integer, String>();
        int n = 1000; //starting size of array
        Timer t = new Timer();
        double timeLimit = 2.0; //Time-limit of sorting time for an array.


        /**"Change valid index number in sortType if you want to use another sorting method
         1: Selecting Sort
         2: Quick Sort
         3: Heap Sort
         4: Bubble Sort
         */

        //Inserting the names of each sorting method into a hash map
        printSortType.put(1, "Selecting Sort");
        printSortType.put(2, "Quick Sort");
        printSortType.put(3, "Heap Sort");
        printSortType.put(4, "Bubble Sort");

        int sortType = 4 ; //To select another sort method, change the integer from 1-4




            //Initiate sorting method
            System.out.println("------>> " + printSortType.get(sortType) + " has been selected <<------" +
                    "\n Timelimit: " + timeLimit);

            while(t.calcTime() <= timeLimit ) { //While sort time is below 2 sec. Increase n elements and resort.
                t = new Timer(); //Reset the old timer with a new one.
                DataArray dataArray = new DataArray(n, sortType);
                System.out.println("\nCurrent arraysize: " + n); //Current array size wih n elements
                t.printTime();                                   //Prints sort time.
                n*=2;                                            //Increase the number of elements in an array with n*2
        }
        System.out.println("\nResults:");
        t.printTime();
        System.out.println(n + " max arraysize tested"); //Prints out the largest array tested before the program
                                                         //terminates.
        System.exit(0); //Terminates the java-process when everything is done.

    }
}
