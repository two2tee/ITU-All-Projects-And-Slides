/**
 * Selection sort
 * Created by Dennis Thinh Tan Nguyen - on 18/11/14.
 * Email: dttn@itu.dk
 */
class SelectionSort extends Sort {


    public static void sort(int[]arr, int n){
        for(int i = 0 ; i < n ; i++){
            int least = i;

            for(int j = i+1 ; j < n ; j++)
            {
                if (arr[least] > arr[j])
                {
                    least = j;
                }
            }
            swap(arr,i,least);
        }

    }

}
