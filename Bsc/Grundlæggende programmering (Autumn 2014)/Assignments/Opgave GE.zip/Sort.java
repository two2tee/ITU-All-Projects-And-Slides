/**
 * This class will be used to inherit common methods
 * Created by Dennis Thinh Tan on 18-Nov-14.
 * Email: dttn@itu.dk
 */
class Sort {
    static void swap(int[] arr, int s, int t)
    {
        int tmp = arr[s];
        arr[s]= arr[t];
        arr[t] = tmp;
    }
}
