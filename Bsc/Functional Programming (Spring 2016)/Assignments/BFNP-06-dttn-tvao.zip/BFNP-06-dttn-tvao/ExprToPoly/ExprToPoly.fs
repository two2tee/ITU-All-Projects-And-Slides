module ExprToPoly

(*#load "ExprParse.fs"*)

open ExprParse

type expr = ExprParse.expr

// Print out a polynomial expression in a pretty string format 
let rec ppExpr = function
  | FNum c -> string(c)
  | FVar s -> s
  | FAdd(e1,e2) -> "(" + (ppExpr e1) + " + " + (ppExpr e2) + ")"
  | FMult(e1,e2) -> (ppExpr e1) + " * " + (ppExpr e2)
  | FExponent(e,n) -> "(" + (ppExpr e) + ")^" + string(n) 

// Replace variables with arbitrary expressions, eg x is replaced by the expression ex = 'px + tdx' 
// e is the whole expression to be traversed for replacement of variables 
// x is what you are searching for and ex is the replacement expression 
let rec subst e (x : string, ex : expr) =
  match e with    
  | FNum c -> FNum c 
  | FVar s -> if (s = x) then ex else FVar s 
  | FAdd(ex1,ex2) -> FAdd((subst ex1 (x, ex)), (subst ex2 (x, ex))) // eg substitute 'x+y' with '(px+tdx) + (py+tdy)' 
  | FMult(ex1,ex2) -> FMult((subst ex1 (x, ex)), (subst ex2 (x, ex))) // same as above with multiplication 
  | FExponent(ex1, i) -> FExponent(subst ex1 (x, ex), i) // eg 'x^2' becomes '(px+tdx)^2 

type atom = ANum of float | AExponent of string * int // Example: '2' or 'x^2' 
type atomGroup = atom list // Combination of above atoms, e.g. '2x^2' 
type simpleExpr = SE of atomGroup list // e.g. '1x^2' becomes 'x^2' and multiple ocurrences like 'x+x' becomes 'x^2'
let isSimpleExprEmpty (SE ags) = ags = [] || ags = [[]] 

let ppAtom = function
  | ANum c -> string(c)
  | AExponent(s,1) -> s
  | AExponent(s,n) -> s+"^"+(string(n))
let ppAtomGroup ag = String.concat "*" (List.map ppAtom ag)
let ppSimpleExpr (SE ags) = String.concat "+" (List.map ppAtomGroup ags)

// Multiply all components and eliminate the paranteses
// Example: '(x+y)*z' becomes 'xz+xy'
let rec combine xss = function
  | [] -> []
  | ys::yss -> List.map ((@) ys) xss @ combine xss yss

// Simplify the polynomial expression as much as possible 
// We multiply all parentheses such that we have an expression with components that are added and multiplied without need of parentheses 
// A simple expression is composed as a list of lists where there are '+' between outer lists and '*' between inner lists 
// Simple expression example: [[ANum 3.0,Anum 1.0],[ANum 2.0]] is equal to '3*1'+ '2' 
let rec simplify = function
  | FNum c -> [[ANum c]]
  | FVar s -> [[AExponent(s,1)]]
  | FAdd(e1,e2) -> simplify e1 @ simplify e2 // Gives a list of lists 
  | FMult(e1,e2) -> combine (simplify e1) (simplify e2) // we have to simplify expressions to FNums and FVars and then multiply
  | FExponent(e1,0) -> [[ANum 1.0]] 
  | FExponent(e1,1) -> simplify e1 
  | FExponent(e1,n) -> simplify e1 @ simplify (FExponent(e1, n-1)) // naive exponent implementation, e.g. 'x^7' becomes 'x * (x*(7-1))' = x^6 etc
  // Consider combine (simplify e1) (simplify (FExponent(e1, n-1))) so multiply components instead of adding them 


// Function makes two simplifications on each atom group
// 1) Atoms x^n are collected such that each variable x is only represented once
// Example: [AExponent ("px",1); AExponent ("px",2)] is reduced to [AExponent ("px",3)] 
// 2) All constants k are multiplied into one product (inner lists are multiplied together)
// Example: atom group [ANum -2.0; ANum -2.0] becomes [ANum 4.0]

let simplifyAtomGroup ag = 

    // Helper function to update a map of variables and their exponents 
    // Atoms are not just added to a map but we first checked if variable already exists 
    let updateMap k e m = if Map.containsKey k m 
                          then Map.add k ((Map.find k m)+e) m // Overwrite existing value 
                          else Map.add k e m
     
    // Helper function (binding without argument) to convert the map of exponents back into a list  
    // Accumulator is an empty map that for each fold takes an atom              
    let mapExponents = 
        List.fold (fun map atom -> match atom with
                                   | AExponent(n,e) -> updateMap n e map // hash map only has one pair for each variable, n is key and e is element
                                   | ANum n -> map) // Handle in product binding below 
                  Map.empty ag // Argument in fold, base case (state or accumulator) is an empty map that is filled with atoms for each step
    
    // Converts output of map from mapExponents with key and value to a list of atoms with AExponents 
    let exponents = List.map (fun (n,e) -> AExponent(n,e)) (Map.toList mapExponents)

    // Helper function to collect the product of the contants 
    // Ignore AExponents and finds product of ANums (2) 
    let product = 
        List.fold (fun atom (ANum s) -> match atom with
                                        | AExponent(n,e) -> ANum s
                                        | ANum n -> ANum (n * s))
                                        // | _ -> failwith "Can only return an Anum") Todo fix ?
                  (ANum 1.0) ag // Argument in fold, fold requires an initial state which is here the product of 1 * ...
    
    // Function result return the resulting product of constants consed with the exponents
    product :: exponents ;; 

// Takes an arbitrary simple expression and simplify it as follows:
// 1) Simiplify each atom group using List.map with function simplifyAtomGroup
// 2) Add all atom groups with constants only, e.g [[ANum 3.0];[ANum 4.0]] is reduced to [ANum 7.0]
// 3) Group similar atom groups into one group, e.g. 'x^2 + x^2' becomes '2*x^2' as shown below  
// e.g. [[AExponent("x",2); [AExponent("x",2);]] is reduced to [[ANum 2.0; AExponent("x",2);]]

let simplifySimpleExpr (SE ags) =

  // Convert list of atom groups from argument to list of simple expression 
  // without parentheses and multiple ocurrences of variables using the simplifyAtomGroup function 
  let ags' = List.map simplifyAtomGroup ags

  // Add atom groups with constants only together
  // Fold takes an explicit initial value for the accumulator 
  // Applies a function f to each atom of collection, threading an accumulator argument through the computation
  // Folding functon is 'List.fold (fun (ANum x) [ANum n] -> ANum (x+n))' 
  // Accumulator or initial value is '(ANum 0.0)' 
  // ags' is the list of simple expressions in the collection 
  let sum = List.fold (fun (ANum x) [ANum n] -> ANum (x+n)) (ANum 0.0) ags'
  let ags' = List.map (fun [ANum n] -> []) ags'

  // Group similar atomGroups into one group 
  let updateMap k m = if Map.containsKey k m 
                      then Map.add k ((Map.find k m)+1) m // 'x^1' + 'x^1' becomes 'x^2' 
                      else Map.add k 1 m // 'x' becomes 'x^1' 
  // Update all occurences of similar variables into one 
  let mapSimilar = List.fold (fun map ag -> updateMap ag map) Map.empty ags'
  // Update all occurences of constants into one sum 
  let similarList = List.map (fun (ag,n) -> (ANum (float n)) :: ag) (Map.toList mapSimilar)

  // Return function result with simplified expression 
  // where variables from atom groups only occur once and constants have been summed together 
  SE ([sum] :: similarList)

let exprToSimpleExpr e = simplifySimpleExpr (SE (simplify e))

type poly = P of Map<int,simpleExpr>

let ppPoly v (P p) =
  let pp (d,ags) =
    let prefix = if d=0 then "" else ppAtom (AExponent(v,d))
    let postfix = if isSimpleExprEmpty ags then "" else "(" + (ppSimpleExpr ags) + ")"
    prefix + postfix
  String.concat "+" (List.map pp (Map.toList p))

(* Collect atom groups into groups with respect to one variable v *)
let rec removeAtom atom list =
    match list with
    |AExponent (s,i)::xs when s = atom -> list @ xs
    |x::xs -> x::removeAtom atom xs
    |[]    -> list

// Collect atom groups into groups with respect to one variable, e.g. 't' 
// Iterates over an atom group ag and try finds the pattern AExponent (v,n) as part of atom group ag for some power n
// If such exists then update map with n -> ag' where ag' is the atom group already in map for key n extended with atom group ag with atom t^n removed 

// Example: splitAG "t" Map.empty [ANum 1.0; AExponent ("pz",1); AExponent ("dz",1); AExponent ("t",2)]
// Returns the map val m : Map<int,simpleExpr> = map [(2, SE [[ANum 1.0; AExponent ("pz",1); AExponent ("dz",1)]])]
// with and entry for 2 mapped to the atom group without the atom AExponent ("t",2).
let splitAG v m = function
| [] -> m // empty map without variable v 
| ag -> // atom group pattern match 
    let eqV = function 
        | AExponent(v',_) -> v = v' 
        | _ -> false

    // Collect atom groups into groups with respect to one variable that is removed from the map and set outside the list 
    let addMap d ag m = 
      if Map.containsKey d m 
      then match Map.find d m with
                                  | SE list -> Map.add d (SE ((removeAtom v ag)::list)) m // Isolate variable v from simple expression and cons the result 
      else Map.add d (SE [(removeAtom v ag)]) m      
    
    // Try find pattern AExponent (v,n) as part of atom group ag for some power n 
    match List.tryFind eqV ag with
      | Some (AExponent(_,d)) ->
        let ag' = List.filter (not << eqV) ag
        addMap d ag' m
      | Some _ -> failwith "splitAG: Must never come here! - ANum will not match eqV"
      | None -> addMap 0 ag m

let simpleExprToPoly (SE ags) v =
  P (List.fold (splitAG v) Map.empty ags)

let exprToPoly e v = (exprToSimpleExpr >> simplifySimpleExpr >> simpleExprToPoly) e v


(* Test Examples *)
(*
let plane = FAdd (FMult (FVar "a", FVar "x"), FAdd (FMult (FVar "b", FVar "y"), FAdd (FMult (FVar "c", FVar "z"), FVar "d")))
let planeStr = "ax+by+cz+d"

let ex = FAdd (FVar "ox", FMult (FVar "t", FVar "dx"))
let ey = FAdd (FVar "oy", FMult (FVar "t", FVar "dy"))
let ez = FAdd (FVar "oz", FMult (FVar "t", FVar "dz"))
let planeSubst = List.fold subst plane [("x",ex);("y",ey);("z",ez)] 
let plane_d = exprToPoly planeSubst "t"
let _ = printf "%s\n" (ppPoly "t" plane_d)
(* Correct result for plane (d+c*oz+b*oy+a*ox)+t(c*dz+b*dy+a*dx) *)

let circle = FAdd (FExponent (FVar "x", 2) ,
                   FAdd (FExponent (FVar "y", 2),
                         FAdd (FExponent (FVar "z", 2),
                               FMult (FNum -1.0, FExponent (FVar "r", 2))))) 
let circleStr = "x^2+y^2+z^2+-1r^2"
let circleSubst = List.fold subst circle [("x",ex);("y",ey);("z",ez)]
let circle_d = exprToPoly circleSubst "t"
let _ = printf "%s\n" (ppPoly "t" circle_d)
(* Correct result for circle
     (oz^2 + oy^2 + ox^2 + -r^2) + t(2*dz*oz+2*dy*oy+2*dx*ox) + t^2(dz^2+dy^2+dx^2)
The constant 2 could be optimized out.
*)

let test03 n =
  let e = FExponent (FAdd (FVar "a", FVar "b"), n)
  simplifySimpleExpr (exprToSimpleExpr e)

let _ = for (i:int) in [1..5] do printf "(a + b)^%d = %s\n" i (ppSimpleExpr(test03 i))
(*
Expected results
(a + b)^1 = a+b
(a + b)^2 = 2*a*b+a^2+b^2
(a + b)^3 = 3*a*b^2+3*a^2*b+a^3+b^3
(a + b)^4 = 4*a*b^3+4*a^3*b+6*a^2*b^2+a^4+b^4
(a + b)^5 = 5*a*b^4+5*a^4*b+10*a^2*b^3+10*a^3*b^2+a^5+b^5
*)  


let test04 n =
  let e = FExponent (FAdd (FVar "a", FAdd(FVar "b", FVar "c")), n)
  simplifySimpleExpr (exprToSimpleExpr e)
let _ = for (i:int) in [1..5] do printf "(a + b + c)^%d = %s\n" i (ppSimpleExpr(test04 i))
(*
   Expected Results:
(a + b + c)^1 = a+b+c
(a + b + c)^2 = 2*a*b+2*a*c+2*b*c+a^2+b^2+c^2
(a + b + c)^3 = 3*a*b^2+3*a*c^2+3*a^2*b+3*a^2*c+3*b*c^2+3*b^2*c+6*a*b*c+a^3+b^3+c^3
(a + b + c)^4 = 4*a*b^3+4*a*c^3+4*a^3*b+4*a^3*c+4*b*c^3+4*b^3*c+6*a^2*b^2+6*a^2*c^2+6*b^2*c^2+12*a*b*c^2+12*a*b^2*c+12*a^2*b*c+a^4+b^4+c^4
(a + b + c)^5 = 5*a*b^4+5*a*c^4+5*a^4*b+5*a^4*c+5*b*c^4+5*b^4*c+10*a^2*b^3+10*a^2*c^3+10*a^3*b^2+10*a^3*c^2+10*b^2*c^3+10*b^3*c^2+20*a*b*c^3+20*a*b^3*c+20*a^3*b*c+30*a*b^2*c^2+30*a^2*b*c^2+30*a^2*b^2*c+a^5+b^5+c^5
*)   


(* Example from rayTracerII.tex *)
let sphere = FAdd(FAdd(FAdd(FExponent(FVar "x",2),
                            FExponent(FVar "y",2)),
                       FExponent(FVar "z",2)),
                  FMult(FNum -1.0,FVar "R"))
let ex' = FAdd(FVar "px", FMult(FVar "t",FVar "dx"))
let ey' = FAdd(FVar "py", FMult(FVar "t",FVar "dy"))
let ez' = FAdd(FVar "pz", FMult(FVar "t",FVar "dz"))
let eR = FNum -1.0
let sphereSubst = List.fold subst sphere [("x",ex');("y",ey');("z",ez');("R",eR)]

(* Result
val sphereSubst : expr =
  FAdd
    (FAdd
       (FAdd
          (FExponent (FAdd (FVar "px",FMult (FVar "t",FVar "dx")),2),
           FExponent (FAdd (FVar "py",FMult (FVar "t",FVar "dy")),2)),
        FExponent (FAdd (FVar "pz",FMult (FVar "t",FVar "dz")),2)),
     FMult (FNum -1.0,FNum -1.0))
*)

let sphereSE = simplify sphereSubst

(* Result
val sphereSE : atom list list =
  [[ANum 1.0; AExponent ("px",1); AExponent ("px",1)];
   [ANum 1.0; AExponent ("px",1); AExponent ("dx",1); AExponent ("t",1)];
   [ANum 1.0; AExponent ("dx",1); AExponent ("t",1); AExponent ("px",1)];
   [ANum 1.0; AExponent ("dx",1); AExponent ("t",1); AExponent ("dx",1);
    AExponent ("t",1)]; [ANum 1.0; AExponent ("py",1); AExponent ("py",1)];
   [ANum 1.0; AExponent ("py",1); AExponent ("dy",1); AExponent ("t",1)];
   [ANum 1.0; AExponent ("dy",1); AExponent ("t",1); AExponent ("py",1)];
   [ANum 1.0; AExponent ("dy",1); AExponent ("t",1); AExponent ("dy",1);
    AExponent ("t",1)]; [ANum 1.0; AExponent ("pz",1); AExponent ("pz",1)];
   [ANum 1.0; AExponent ("pz",1); AExponent ("dz",1); AExponent ("t",1)];
   [ANum 1.0; AExponent ("dz",1); AExponent ("t",1); AExponent ("pz",1)];
   [ANum 1.0; AExponent ("dz",1); AExponent ("t",1); AExponent ("dz",1);
    AExponent ("t",1)]; [ANum -1.0; ANum -1.0]]
*)

let _ = ppSimpleExpr (SE sphereSE)

(* Result:
> val it : string =
  "1*px*px+1*px*dx*t+1*dx*t*px+1*dx*t*dx*t+1*py*py+1*py*dy*t+1*dy*t*py+1*dy*t*dy*t+1*pz*pz+1*pz*dz*t+1*dz*t*pz+1*dz*t*dz*t+-1*-1"

*)

(* Simplifying Atom Groups *)
let _ = simplifyAtomGroup [AExponent ("px",1); AExponent ("px",2); ANum -2.0; ANum -2.0]
(* Result
> val it : atom list = [ANum 4.0; AExponent ("px",3)]
*)

(* Simplifying Simple Expressions *)
let _ = simplifySimpleExpr 
          (SE [[ANum 3.0];[ANum 4.0];[AExponent("x",2);AExponent("y",3)];[AExponent("x",2); AExponent("y",3)]])
(* Result
> val it : simpleExpr =
  SE [[ANum 7.0]; [ANum 2.0; AExponent ("x",2); AExponent ("y",3)]]
*)

(*
let m = splitAG "t" Map.empty [ANum 1.0; AExponent ("pz",1); AExponent ("dz",1); AExponent ("t",2)]
let m = splitAG "t" m [ANum 1.0; AExponent ("pz",1); AExponent ("dz",1); AExponent ("t",2)]
*)
(* Result:
> 
val m : Map<int,simpleExpr> =
  map [(2, SE [[ANum 1.0; AExponent ("pz",1); AExponent ("dz",1)]])]

> 
val m : Map<int,simpleExpr> =
  map
    [(2,
      SE
        [[ANum 1.0; AExponent ("pz",1); AExponent ("dz",1)];
         [ANum 1.0; AExponent ("pz",1); AExponent ("dz",1)]])]
*)
*)
