﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Introduction.Tests
{
    /// <summary>
    /// Test class for <see cref="Types"/>, intended as exercises to learn about C# types.
    /// Modify <see cref="Types"/> in order to make the tests pass.
    /// </summary>
    [TestClass]
    public class TypesTest
    {
        Types _types;

        /// <summary>
        /// This initializer is called prior to running each test.
        /// </summary>
        [TestInitialize]
        public void Initialize()
        {
            _types = new Types();
        }

        /// <summary>
        /// Exercise on different types of comparisons for value types.
        /// </summary>
        [TestMethod]
        public void ValueTypeEquality()
        {
            Assert.AreEqual(42, _types.GetInteger());  // 'Equals' comparison.
            Assert.AreNotSame(42, _types.GetInteger()); // Reference comparison.
        }

        /// <summary>
        /// Exercise on different types of comparisons for reference types.
        /// </summary>
        [TestMethod]
        public void ReferenceTypeEquality()
        {
            Vehicle vehicle1 = _types.GetVehicle1();
            Vehicle vehicle2 = _types.GetVehicle2();

            Assert.AreEqual(new Vehicle("Ferrari"), _types.GetVehicle1());
            Assert.AreSame(_types.GetVehicle1(), _types.GetVehicle2());
        }
    }
}
