﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Introduction.Tests
{
    /// <summary>
    /// Test class, intended as a general introduction to C#.
    /// Modify <see cref="Introduction"/> in order to make the tests pass.
    /// </summary>
    [TestClass]
    public class IntroductionTest
    {
        Introduction _introduction;

        [TestInitialize]
        public void Initialize()
        {
            _introduction = new Introduction();
        }

        /// <summary>
        /// When the string contains "error", an exception should be thrown.
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestForIncorrectArgument()
        {
            _introduction.HandleArgument("This string contains an error!");
        }

        /// <summary>
        /// When the string does not contain "error", no exception should be thrown.
        /// </summary>
        [TestMethod]
        public void TestForCorrectArgument()
        {
            _introduction.HandleArgument("All your base belong to us!");
        }
    }
}
