﻿using System;

namespace Introduction
{
    /// <summary>
    /// Class, intended as exercise to learn about C# and testing in C#.
    /// Implement the methods in this class so that all tests pass.
    /// Inspect the tests in order to find out how to make them pass.
    /// </summary>
    public class Introduction
    {
        public void HandleArgument(string argument)
        {
            throw new NotImplementedException();
        }
    }
}
