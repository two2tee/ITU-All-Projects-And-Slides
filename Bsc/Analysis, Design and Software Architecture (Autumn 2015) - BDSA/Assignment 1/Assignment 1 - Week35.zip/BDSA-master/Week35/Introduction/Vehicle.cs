﻿namespace Introduction
{
    /// <summary>
    /// A dummy class for exercise purposes.
    /// </summary>
    public class Vehicle
    {
        /// <summary>
        /// The name of the vehicle.
        /// </summary>
        public readonly string Name;

        /// <summary>
        /// Create a new vehicle with the specified name.
        /// </summary>
        /// <param name="name">The name of the vehicle.</param>
        public Vehicle(string name)
        {
            Name = name;
        }

        public override bool Equals(object obj)
        {
            var vehicle = obj as Vehicle;

            if (vehicle == null)
            {
                return false;
            }

            return vehicle.Name == Name;
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode();
        }
    }
}
