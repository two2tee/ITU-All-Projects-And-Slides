﻿using System;

namespace Introduction
{
    /// <summary>
    /// Class, intended as exercise to learn about C# types.
    /// Implement the methods in this class so that all tests pass.
    /// Inspect the tests in order to find out how to make them pass.
    /// </summary>
    public class Types
    {
        public int GetInteger()
        {
            throw new NotImplementedException();
        }

        public Vehicle GetVehicle1()
        {
            throw new NotImplementedException();
        }

        public Vehicle GetVehicle2()
        {
            throw new NotImplementedException();
        }
    }
}
