﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace IsPowerOf.Tests
{
    /// <summary>
    /// Test class for <see cref="Calculator"/>.
    /// </summary>
    [TestClass]
    public class CalculatorTest
    {
        [TestMethod]
        public void IsPowerOfTest_IsTrue()
        {
            Assert.IsTrue(Calculator.IsPowerOf(16, 4)); // 4^2
            Assert.IsTrue(Calculator.IsPowerOf(8, 2)); // 2^3
            Assert.IsTrue(Calculator.IsPowerOf(10000, 10)); // 10^4
        }

        [TestMethod]
        public void IsPowerOfTest_IsFalse()
        {
            Assert.IsFalse(Calculator.IsPowerOf(10, 2));
            Assert.IsFalse(Calculator.IsPowerOf(100, 8));
        }

        /// <summary>
        /// For negative numbers, depending on the power raised to is odd or even, the sign of the output changes.
        /// </summary>
        [TestMethod]
        public void IsPowerOfTest_NegativeNumbers()
        {
            Assert.IsTrue(Calculator.IsPowerOf(16, -4)); // -4^2
            Assert.IsTrue(Calculator.IsPowerOf(-8, -2)); // -2^3
            Assert.IsTrue(Calculator.IsPowerOf(10000, -10)); // -10^4
        }

        /// <summary>
        /// Zero to any power > 0 is 0. Zero to the power of 0 is 1.
        /// </summary>
        [TestMethod]
        public void IsPowerOfTest_Zero()
        {
            Assert.IsTrue(Calculator.IsPowerOf(1, 0)); // 0^0
            Assert.IsTrue(Calculator.IsPowerOf(0, 0)); // 0^any other number
        }

        /// <summary>
        /// One to any power is always one.
        /// </summary>
        [TestMethod]
        public void IsPowerOfTest_One()
        {
            Assert.IsTrue(Calculator.IsPowerOf(1, 1)); // 1^1
            Assert.IsFalse(Calculator.IsPowerOf(10, 1));
        }
    }
}
