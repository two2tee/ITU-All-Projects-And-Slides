﻿using System;
using System.IO;
using BibliographyParser;
using BibliographyParser.BibTex;
using System.Collections.Generic;

namespace BibTexParserGui
{
    /// <summary>
    /// Console application for <see cref="BibTexParser"/>.
    /// </summary>
    class BibTexCmdGui
    {
        static void Main(string[] args)
        {
            var program = new BibTexCmdGui();
            program.PrintBibliography();
        }

        readonly IBibliographyParser _parser = new BibTexParser(new ItemValidator());

        void PrintBibliography()
        {
            Console.WriteLine("Hi!");
            Console.WriteLine("Welcome to the BibTex parser.");

            var data = PromtUserForFile();
            try
            {
                List<Item> bibliography = _parser.Parse(data);
                Console.WriteLine("\nThe bibliography contains {0} items:", bibliography.Count);

                foreach (var item in bibliography)
                {
                    Console.WriteLine("\t{0}", item.Fields[Item.FieldType.Title]);
                }
                Console.WriteLine();
            }
            catch (InvalidDataException)
            {
                Console.WriteLine("The specified file contains invalid BibTex data and could not be parsed.");
            }

            Console.WriteLine("Please enter to exit.");
            Console.ReadLine();
        }
 
        string PromtUserForFile()
        {
            try
            {
                Console.Write("Please enter file location.\n> ");
                return File.ReadAllText(Console.ReadLine());
            }
            // Normally, you catch specific exceptions, providing detailed information to the user for each, and potentially different resolutions.
            // Since the command line is just here for demonstration and testing purposes, we treat them all the same.
            catch (Exception e)
            {
                Console.WriteLine("Invalid path. Please try again.");
                Console.WriteLine("Exception message: {0}", e);
                return PromtUserForFile();
            }
        }
    }
}
