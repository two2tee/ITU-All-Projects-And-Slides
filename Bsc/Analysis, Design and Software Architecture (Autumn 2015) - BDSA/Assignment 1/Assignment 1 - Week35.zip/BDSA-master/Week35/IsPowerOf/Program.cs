﻿using System;

namespace IsPowerOf
{
    /// <summary>
    /// Console application which takes two numbers as command line arguments.
    /// The output indicates whether the first passed number is a power of the second.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // Check for correct arguments.
            int a = 0;
            int b = 0;
            bool correctArgs = args.Length == 2;
            if (correctArgs)
            {
                correctArgs = int.TryParse(args[0], out a);
                correctArgs &= int.TryParse(args[1], out b);
            }
            if (!correctArgs)
            {
                Console.WriteLine("Two whole numbers are expected to be passed as arguments, separated by a space.");
                Console.WriteLine("The function returns whether the first number is a power of the second number.");
                return;
            }

            Console.WriteLine(Calculator.IsPowerOf(a, b));
        }
    }
}
