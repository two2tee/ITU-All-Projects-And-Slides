﻿using System;

namespace IsPowerOf
{
    /// <summary>
    /// A calculator class (for exercise purposes, you most likely would never write this), containing mathematical operations.
    /// </summary>
    public static class Calculator
    {
        /// <summary>
        /// Determines whether a given number is a power of another, disregarding negative exponents.
        /// </summary>
        /// <param name="a">The number to determine whether it is a power of <paramref name="b" />.</param>
        /// <param name="b">The number of which to determine whether <paramref name="a" /> is a power of.</param>
        /// <returns>true when <paramref name="a" /> is a power of <paramref name="b" />; false otherwise.</returns>
        public static bool IsPowerOf(int a, int b)
        {
            throw new NotImplementedException();
        }
    }
}
