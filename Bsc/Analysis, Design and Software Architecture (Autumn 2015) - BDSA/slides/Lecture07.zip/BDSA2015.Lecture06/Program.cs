﻿namespace BDSA2015.Lecture06
{
    class Program
    {
        static void Main(string[] args)
        {
            RunTimeBridge.Execute("csv");
        }
    }
}
