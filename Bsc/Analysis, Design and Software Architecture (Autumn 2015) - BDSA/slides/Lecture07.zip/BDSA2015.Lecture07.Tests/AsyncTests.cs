﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;

namespace BDSA2015.Lecture07.Tests
{
    [TestClass]
    public class AsyncTests
    {
        [TestMethod]
        public async Task AsyncTest()
        {
            Assert.Fail();
        }
    }
}
