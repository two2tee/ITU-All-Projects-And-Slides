﻿namespace BDSA2015.Lecture04
{
    public enum Gender
    {
        Female,
        Male
    }
}
