﻿using System.Collections.Generic;
using BDSA2015.Lecture05.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Data.Entity;
using System.Linq;

namespace BDSA2015.Lecture05.Tests
{
    [TestClass]
    public class EntityRepositoryTests
    {
        private Mock<ICharacterContext> _context;
        private Mock<DbSet<Character>> _set;
        private EntityRepository _repository;
        private List<Character> _data;

        [TestInitialize]
        public void Initialize()
        {
            _data = new List<Character>
            {
                new Character {Id = 1, GivenName = "Clark", Surname = "Kent", AlterEgo = "Superman"},
                new Character {Id = 2, GivenName = "Bruce", Surname = "Wayne", AlterEgo = "Batman"},
                new Character {Id = 3, GivenName = "Wonder Woman", AlterEgo = "Princess Diana of Themyscira"},
                new Character {Id = 4, GivenName = "Bruce", Surname = "Banner", AlterEgo = "Hulk"},
                new Character {Id = 5, GivenName = "Steve", Surname = "Rogers", AlterEgo = "Captain America"},
                new Character {Id = 6, GivenName = "Tony", Surname = "Stark", AlterEgo = "Iron Man"},
                new Character {Id = 7, GivenName = "James", Surname = "Howlett", AlterEgo = "Wolverine"},
                new Character {Id = 8, GivenName = "Selina", Surname = "Kyle", AlterEgo = "Catwoman"}
            };
            _set = MockUtility.CreateMockDbSet(_data);
            var context = new Mock<ICharacterContext>();
            context.Setup(s => s.Characters).Returns(_set.Object);

            _context = context;
            _repository = new EntityRepository(_context.Object);
        }

        [TestMethod]
        public void Put()
        {
            var context = new Mock<ICharacterContext>();
            var set = new Mock<DbSet<Character>>();
            var character = new Character();
            context.Setup(s => s.Characters).Returns(set.Object);
            set.Setup(s => s.Find(1)).Returns(character);

            using (var repository = new EntityRepository(context.Object))
            {
                repository.Put(new CharacterDto { Id = 1 });

                context.Verify(r => r.SaveChanges(), Times.Once);
            }
        }

        [TestMethod]
        public void GetById()
        {
            var no2 = _repository.Get(2);

            Assert.AreEqual("Batman", no2.AlterEgo);
        }

        [TestMethod]
        public void GetByAlterEgo()
        {
            using (var repository = new EntityRepository(_context.Object))
            {
                var iron = repository.Get('I').ToList();

                Assert.AreEqual("Iron Man", iron[0].AlterEgo);
            }
        }
    }
}
