﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;

namespace BDSA2015.Lecture05.Tests
{
    public static class MockUtility
    {
        public static Mock<DbSet<T>> CreateMockDbSet<T>(IEnumerable<T> items) where T : class
        {
            var data = items.AsQueryable();
            var set = new Mock<DbSet<T>>();
            set.As<IQueryable<T>>().Setup(m => m.Provider).Returns(data.Provider);
            set.As<IQueryable<T>>().Setup(m => m.Expression).Returns(data.Expression);
            set.As<IQueryable<T>>().Setup(m => m.ElementType).Returns(data.ElementType);
            set.As<IQueryable<T>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            return set;
        }
    }
}
