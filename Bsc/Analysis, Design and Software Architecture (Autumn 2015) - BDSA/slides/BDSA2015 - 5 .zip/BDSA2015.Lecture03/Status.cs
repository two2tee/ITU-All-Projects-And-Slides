﻿namespace BDSA2015.Lecture03
{
    public enum Status
    {
        Ok,
        Fail,
        Pending,
        Missing
    }
}