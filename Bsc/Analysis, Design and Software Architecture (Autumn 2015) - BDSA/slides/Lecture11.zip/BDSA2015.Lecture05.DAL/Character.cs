﻿namespace BDSA2015.Lecture05.DAL
{
    public class Character
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AKA { get; set; }
    }
}
