﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDSA2015.Lecture11.App
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
