﻿namespace BDSA2015.Lecture09.Universal.ViewModels.DesignTime
{
    public class CustomerDesignTimeViewModel
    {
        public int Id => 1;
        public string CompanyName => "Company Name";
        public string ContactName => "Contact Name";
        public string City => "City";
        public string Telephone => "Telephone";
    }
}
