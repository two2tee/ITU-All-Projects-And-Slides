﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Data.Entity;
using System.Linq;

namespace BDSA2015.Lecture03
{
    internal class Program
    {
        private static void Main(string[] args)
        {
        }
    }
}
