﻿namespace BDSA2015.Lecture08.Universal.Model
{
    public class Album
    {
        public string Artist { get; set; }

        public string Title { get; set; }

        public int? Year { get; set; }

        public string Cover { get; set; }
    }
}
